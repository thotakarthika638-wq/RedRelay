// Localities with coordinates (sample cities). Used for registration, hospital location and proximity search.
export const GEO = {
  Hyderabad: {
    Madhapur: [17.4483, 78.3915], Gachibowli: [17.4401, 78.3489], Kondapur: [17.46, 78.364],
    Kukatpally: [17.4948, 78.3996], Miyapur: [17.4969, 78.3548], Ameerpet: [17.4375, 78.4483],
    Begumpet: [17.444, 78.4676], Secunderabad: [17.4399, 78.4983], 'Banjara Hills': [17.4126, 78.4482],
    'Jubilee Hills': [17.4326, 78.4071], Uppal: [17.4058, 78.5591], 'LB Nagar': [17.3457, 78.5522],
    Dilsukhnagar: [17.3688, 78.5247], Medchal: [17.6297, 78.4814],
  },
  Bengaluru: {
    Koramangala: [12.9352, 77.6245], Indiranagar: [12.9784, 77.6408], Whitefield: [12.9698, 77.75],
    Jayanagar: [12.9299, 77.5838], 'HSR Layout': [12.9116, 77.6474],
  },
};

export const coordsOf = (city, locality) => GEO[city]?.[locality];

export function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371, rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(lat2 - lat1), dLon = rad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// Estimated driving minutes: road factor 1.35 over straight line, 24 km/h urban average.
export const etaMinutes = (km) => Math.max(3, Math.round(((km * 1.35) / 24) * 60));
