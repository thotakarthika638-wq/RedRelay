import path from 'node:path';
import { fileURLToPath } from 'node:url';

const file = process.env.DB_FILE || path.join(path.dirname(fileURLToPath(import.meta.url)), 'redrelay.db');

// Prefer better-sqlite3; fall back to Node's built-in node:sqlite (Node >= 22.5) if the native module is missing.
let db;
try {
  const { default: Database } = await import('better-sqlite3');
  db = new Database(file);
  db.pragma('journal_mode = WAL');
} catch {
  const { DatabaseSync } = await import('node:sqlite');
  db = new DatabaseSync(file);
}
export { db };

db.exec(`
CREATE TABLE IF NOT EXISTS donors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  initials TEXT NOT NULL,
  phone TEXT NOT NULL,              -- PRIVATE: never returned by public endpoints
  blood_group TEXT NOT NULL,
  city TEXT NOT NULL,
  locality TEXT NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  available INTEGER NOT NULL DEFAULT 1,
  last_donation_at INTEGER,
  locked_until INTEGER,             -- 90-day clinical recovery lock
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_name TEXT NOT NULL,
  hospital TEXT NOT NULL,
  city TEXT NOT NULL,
  locality TEXT NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  blood_group TEXT NOT NULL,
  units_needed INTEGER NOT NULL,
  units_committed INTEGER NOT NULL DEFAULT 0,
  units_received INTEGER NOT NULL DEFAULT 0,
  urgency_deadline INTEGER NOT NULL,
  doctor_name TEXT NOT NULL,
  doctor_contact TEXT NOT NULL,     -- PRIVATE
  note TEXT,
  status TEXT NOT NULL DEFAULT 'open',   -- open | responded | in_transit | closed
  closed_reason TEXT,                    -- received | expired | cancelled
  manage_token TEXT NOT NULL,            -- family access code
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS fulfillments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id INTEGER NOT NULL,
  donor_id INTEGER NOT NULL,
  units INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'committed', -- committed | donated
  created_at INTEGER NOT NULL,
  donated_at INTEGER
);
CREATE TABLE IF NOT EXISTS relay_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id INTEGER NOT NULL,
  donor_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sms_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id INTEGER NOT NULL,
  donor_id INTEGER NOT NULL,
  body TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
`);

// Query indexes for common feed, matching, history and expiry paths.
db.exec(`
CREATE INDEX IF NOT EXISTS idx_requests_status_deadline ON requests(status, urgency_deadline);
CREATE INDEX IF NOT EXISTS idx_requests_expiry ON requests(status, expires_at);
CREATE INDEX IF NOT EXISTS idx_donors_group_city_availability ON donors(blood_group, city, available);
CREATE INDEX IF NOT EXISTS idx_fulfillments_request_donor ON fulfillments(request_id, donor_id);
CREATE INDEX IF NOT EXISTS idx_fulfillments_donor_created ON fulfillments(donor_id, created_at);
CREATE INDEX IF NOT EXISTS idx_relay_messages_donor_created ON relay_messages(donor_id, created_at);
CREATE INDEX IF NOT EXISTS idx_sms_log_request_created ON sms_log(request_id, created_at);
`);
