import { db } from './db.js';
import { GEO } from './geo.js';

const HOUR = 3600e3;

// [name, group, city, locality, phone]
const DONORS = [
  ['Arjun Reddy', 'B+', 'Hyderabad', 'Madhapur', '9000000001'],
  ['Sneha Iyer', 'O+', 'Hyderabad', 'Gachibowli', '9000000002'],
  ['Imran Khan', 'O-', 'Hyderabad', 'Banjara Hills', '9000000003'],
  ['Lakshmi Prasad', 'A+', 'Hyderabad', 'Kukatpally', '9000000004'],
  ['Rohit Verma', 'B+', 'Hyderabad', 'Jubilee Hills', '9000000005'],
  ['Fatima Begum', 'AB+', 'Hyderabad', 'Ameerpet', '9000000006'],
  ['Karthik Rao', 'O+', 'Hyderabad', 'Kondapur', '9000000007'],
  ['Divya Menon', 'A-', 'Hyderabad', 'Begumpet', '9000000008'],
  ['Suresh Naidu', 'B-', 'Hyderabad', 'Secunderabad', '9000000009'],
  ['Anjali Sharma', 'O+', 'Hyderabad', 'Miyapur', '9000000010'],
  ['Vikram Singh', 'AB-', 'Hyderabad', 'Uppal', '9000000011'],
  ['Pooja Gupta', 'O+', 'Hyderabad', 'LB Nagar', '9000000012'],
  ['Mohammed Faizan', 'B+', 'Hyderabad', 'Dilsukhnagar', '9000000013'],
  ['Harini Krishnan', 'A+', 'Hyderabad', 'Madhapur', '9000000014'],
  ['Naveen Kumar', 'O-', 'Hyderabad', 'Kukatpally', '9000000015'],
  ['Swathi Reddy', 'B+', 'Hyderabad', 'Medchal', '9000000016'],
  ['Ravi Teja', 'O+', 'Hyderabad', 'Secunderabad', '9000000017'],
  ['Nisha Patel', 'A+', 'Hyderabad', 'Gachibowli', '9000000018'],
  ['Srinivas Goud', 'B+', 'Hyderabad', 'Uppal', '9000000019'],
  ['Tanvi Joshi', 'AB+', 'Hyderabad', 'Jubilee Hills', '9000000020'],
  ['Adil Hussain', 'O+', 'Hyderabad', 'Banjara Hills', '9000000021'],
  ['Meera Nair', 'A-', 'Hyderabad', 'Kondapur', '9000000022'],
  ['Prakash Rao', 'O+', 'Hyderabad', 'Ameerpet', '9000000023'],
  ['Kavya Shetty', 'B-', 'Hyderabad', 'Miyapur', '9000000024'],
  ['Deepak Hegde', 'O+', 'Bengaluru', 'Koramangala', '9000000025'],
  ['Ananya Bhat', 'AB+', 'Bengaluru', 'Indiranagar', '9000000026'],
  ['Rahul Desai', 'B+', 'Bengaluru', 'Whitefield', '9000000027'],
  ['Shreya Kulkarni', 'A+', 'Bengaluru', 'Jayanagar', '9000000028'],
  ['Yusuf Ali', 'O-', 'Bengaluru', 'HSR Layout', '9000000029'],
  ['Preeti Das', 'AB-', 'Bengaluru', 'Koramangala', '9000000030'],
];

// [patient, hospital, city, locality, group, units, hoursLeft, doctor, doctorPhone, note]
const REQUESTS = [
  ['Ramesh Kumar', 'Apollo Hospital', 'Hyderabad', 'Jubilee Hills', 'B+', 2, 4, 'Dr. S. Mehta', '9100000001', 'Emergency surgery - 2 units B+ needed'],
  ['Zainab Sheikh', 'Yashoda Hospital', 'Hyderabad', 'Secunderabad', 'O-', 3, 2, 'Dr. A. Rahman', '9100000002', 'Road-accident trauma, ongoing bleed'],
  ['Baby of Priya N.', 'Care Hospital', 'Hyderabad', 'Banjara Hills', 'A+', 1, 10, 'Dr. K. Lakshmi', '9100000003', 'Post-partum haemorrhage'],
  ['Gopal Hegde', 'Manipal Hospital', 'Bengaluru', 'Indiranagar', 'AB-', 2, 6, 'Dr. V. Rao', '9100000004', 'Scheduled cardiac bypass, rare group'],
  ['Mahesh Babu', 'KIMS Hospital', 'Hyderabad', 'Secunderabad', 'O+', 2, 3, 'Dr. P. Reddy', '9100000005', 'Liver transplant support'],
];

export function seed({ reset = false } = {}) {
  if (reset) for (const t of ['donors', 'requests', 'fulfillments', 'relay_messages', 'sms_log']) db.exec(`DELETE FROM ${t}`);
  if (db.prepare('SELECT COUNT(*) AS c FROM donors').get().c > 0) return false;
  const now = Date.now();
  const insD = db.prepare(`INSERT INTO donors (name,initials,phone,blood_group,city,locality,lat,lng,available,created_at)
    VALUES (?,?,?,?,?,?,?,?,1,?)`);
  DONORS.forEach(([name, g, city, loc, phone], i) => {
    const [lat, lng] = GEO[city][loc];
    const jl = ((i * 37) % 10 - 5) * 0.0012, jn = ((i * 53) % 10 - 5) * 0.0012; // spread donors within a locality
    const initials = name.split(' ').map((p) => p[0]).join('.') + '.';
    insD.run(name, initials, phone, g, city, loc, lat + jl, lng + jn, now - i * 86400e3);
  });
  const insR = db.prepare(`INSERT INTO requests (patient_name,hospital,city,locality,lat,lng,blood_group,units_needed,
    urgency_deadline,doctor_name,doctor_contact,note,manage_token,created_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  REQUESTS.forEach(([p, h, city, loc, g, u, hrs, dn, dp, note], i) => {
    const [lat, lng] = GEO[city][loc];
    insR.run(p, h, city, loc, lat, lng, g, u, now + hrs * HOUR, dn, dp, note, `demo-${i + 1}`, now - 25 * 60e3 * (i + 1), now + 24 * HOUR - 25 * 60e3 * (i + 1));
  });
  // Pre-commit a few donors so the feed shows live progress.
  const commit = (reqId, donorId) => {
    db.prepare('INSERT INTO fulfillments (request_id,donor_id,units,created_at) VALUES (?,?,1,?)').run(reqId, donorId, now - 10 * 60e3);
    db.prepare('UPDATE requests SET units_committed = units_committed + 1 WHERE id=?').run(reqId);
  };
  commit(2, 3); db.prepare("UPDATE requests SET status='responded' WHERE id=2").run();
  commit(5, 17); commit(5, 7); db.prepare("UPDATE requests SET status='in_transit' WHERE id=5").run();
  return true;
}

if (process.argv[1] && process.argv[1].endsWith('seed.js')) {
  const did = seed({ reset: process.argv.includes('--reset') });
  console.log(did ? 'Seeded 30 donors and 5 emergency requests.' : 'Database already has data (use --reset).');
}
