import { canDonate } from './compat.js';

/** Explainable 100-point donor ranking; never overrides clinical compatibility. */
export function scoreDonorMatch({ donor, request, distanceKm, committed = false, now = Date.now() }) {
  if (!donor || !request || !canDonate(donor.blood_group, request.blood_group)) return null;
  const radius = 100;
  const proximity = Math.max(0, Math.round(35 * (1 - Math.min(distanceKm, radius) / radius)));
  const exact = donor.blood_group === request.blood_group ? 25 : 0;
  const urgency = Math.max(0, Math.min(20, Math.round(20 * (1 - Math.max(0, request.urgency_deadline - now) / (24 * 60 * 60 * 1000)))));
  const availability = donor.available ? 10 : 0;
  const commitment = committed ? 0 : 10;
  const score = Math.max(0, Math.min(100, proximity + exact + urgency + availability + commitment));
  const reasons = [];
  if (exact) reasons.push('Exact blood-group match'); else reasons.push('Compatible blood group');
  if (distanceKm <= 10) reasons.push('Nearby donor');
  else if (distanceKm <= 25) reasons.push('Within 25 km');
  if (urgency >= 15) reasons.push('Urgent request');
  if (committed) reasons.push('Already committed');
  return { score, tier: score >= 80 ? 'Priority' : score >= 60 ? 'Strong' : 'Eligible', reasons };
}


/** 0–100 request urgency score with an explainable breakdown. */
export function scoreRequestPriority(request, now = Date.now()) {
  const remaining = Math.max(0, request.units_needed - request.units_committed);
  const deadlineHours = Math.max(0, (request.urgency_deadline - now) / 3600000);
  const deadlineScore = Math.max(0, Math.min(60, Math.round(60 * (1 - deadlineHours / 24))));
  const shortageScore = Math.min(40, remaining * 10);
  const score = Math.min(100, deadlineScore + shortageScore);
  return {
    score,
    tier: score >= 80 ? 'Critical' : score >= 60 ? 'High' : score >= 35 ? 'Medium' : 'Low',
    remaining_units: remaining,
    deadline_hours: Math.round(deadlineHours * 10) / 10,
    breakdown: { deadline: deadlineScore, shortage: shortageScore },
  };
}
