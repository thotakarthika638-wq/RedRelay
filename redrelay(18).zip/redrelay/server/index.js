import express from 'express';
import cors from 'cors';
import crypto from 'node:crypto';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { db } from './db.js';
import { seed } from './seed.js';
import { BLOOD_GROUPS, CAN_DONATE_TO, canDonate, eligibleDonorGroups } from './compat.js';
import { GEO, coordsOf, haversineKm, etaMinutes } from './geo.js';
import { scoreDonorMatch, scoreRequestPriority } from './matching.js';

seed();

const app = express();
// Secure-by-default HTTP policy. Explicitly allow local dev origins and configured deployments.
const allowedOrigins = new Set((process.env.CORS_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173,http://localhost:4000,http://127.0.0.1:4000')
  .split(',').map((x) => x.trim()).filter(Boolean));
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1' ? 1 : false);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Cache-Control', 'no-store');
  next();
});
app.use(cors({ origin(origin, cb) {
  if (!origin || allowedOrigins.has(origin)) return cb(null, true);
  return cb(new Error('Origin not allowed by CORS policy'));
}, methods: ['GET', 'POST', 'PATCH', 'OPTIONS'], allowedHeaders: ['Content-Type'], maxAge: 600 }));
app.use(express.json({ limit: '50kb', strict: true }));

// Small in-memory rate limiter (use a shared store for multi-instance deployments).
const rateBuckets = new Map();
function rateLimit({ windowMs, max, keyPrefix }) {
  return (req, res, next) => {
    const key = `${keyPrefix}:${req.ip}`;
    const t = now(); let bucket = rateBuckets.get(key);
    if (!bucket || t - bucket.start >= windowMs) bucket = { start: t, count: 0 };
    bucket.count++; rateBuckets.set(key, bucket);
    if (bucket.count > max) {
      res.setHeader('Retry-After', String(Math.ceil((windowMs - (t - bucket.start)) / 1000)));
      return res.status(429).json({ error: 'Too many requests. Please wait and try again.' });
    }
    next();
  };
}
app.use('/api', rateLimit({ windowMs: 60_000, max: 120, keyPrefix: 'api' }));
app.use('/api', (req, res, next) => {
  if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method))
    return rateLimit({ windowMs: 60_000, max: 30, keyPrefix: 'write' })(req, res, next);
  next();
});
const validateRecordId = (req, res, next, value) => {
  if (!/^\d{1,12}$/.test(String(value)) || Number(value) < 1) return bad(res, 'Invalid record ID.');
  next();
};
app.param('id', validateRecordId);
app.param('fid', validateRecordId);

const HOUR = 3600e3, MIN = 60e3, LOCK_DAYS = 90;
const now = () => Date.now();
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });

/* ---------- helpers ---------- */
const maskPhone = (p) => '••••••' + String(p).slice(-2);
const shortPatient = (n) => {
  const parts = n.trim().split(/\s+/);
  return parts.length === 1 ? parts[0] : `${parts[0]} ${parts[parts.length - 1][0]}.`;
};
const initialsOf = (n) => n.trim().split(/\s+/).map((p) => p[0].toUpperCase()).join('.') + '.';
const lockedNow = (d) => !!d.locked_until && d.locked_until > now();
const isAvailable = (d) => !!d.available && !lockedNow(d);

function sweep() {
  db.prepare("UPDATE requests SET status='closed', closed_reason='expired' WHERE status!='closed' AND expires_at < ?").run(now());
}

// Public view: no phone numbers, no family access code, patient name shortened.
function publicRequest(r) {
  return {
    id: r.id, patient: shortPatient(r.patient_name), hospital: r.hospital, city: r.city, locality: r.locality,
    lat: r.lat, lng: r.lng, blood_group: r.blood_group, units_needed: r.units_needed,
    units_committed: r.units_committed, units_received: r.units_received,
    urgency_deadline: r.urgency_deadline, doctor_name: r.doctor_name, doctor_contact_masked: maskPhone(r.doctor_contact),
    doctor_verified: true, note: r.note, status: r.status, closed_reason: r.closed_reason,
    created_at: r.created_at, expires_at: r.expires_at,
    eligible_groups: eligibleDonorGroups(r.blood_group),
  };
}
const publicDonor = (d) => ({
  id: d.id, initials: d.initials, blood_group: d.blood_group, city: d.city, locality: d.locality,
  available: isAvailable(d), locked_until: lockedNow(d) ? d.locked_until : null,
});
const getRequest = (id) => db.prepare('SELECT * FROM requests WHERE id=?').get(Number(id));
const getDonor = (id) => db.prepare('SELECT * FROM donors WHERE id=?').get(Number(id));

function recalcStatus(reqId) {
  const r = getRequest(reqId);
  if (!r || r.status === 'closed') return;
  let status = r.status;
  if (r.units_committed >= r.units_needed) status = 'in_transit';
  else if (r.units_committed > 0 && r.status === 'open') status = 'responded';
  else if (r.units_committed === 0 && r.status !== 'in_transit') status = 'open';
  db.prepare('UPDATE requests SET status=? WHERE id=?').run(status, reqId);
}

// Matching engine: compatible group + available + city filter + radius filter, nearest first.
function findMatches(r, { radius = 25, city = null } = {}) {
  const groups = eligibleDonorGroups(r.blood_group);
  const rows = db.prepare(`SELECT * FROM donors WHERE blood_group IN (${groups.map(() => '?').join(',')})`).all(...groups);
  const committed = new Set(db.prepare("SELECT donor_id FROM fulfillments WHERE request_id=?").all(r.id).map((f) => f.donor_id));
  return rows
    .filter((d) => isAvailable(d) || committed.has(d.id))
    .filter((d) => !city || city === 'all' || d.city === city)
    .map((d) => {
      const km = haversineKm(r.lat, r.lng, d.lat, d.lng);
      return { d, km };
    })
    .filter(({ km }) => km <= radius)
    .sort((a, b) => a.km - b.km)
    .map(({ d, km }) => ({
      ...publicDonor(d),
      lat: Math.round(d.lat * 100) / 100, lng: Math.round(d.lng * 100) / 100, // fuzzed ~1 km for privacy
      distance_km: Math.round(km * 10) / 10, eta_min: etaMinutes(km),
      exact_match: d.blood_group === r.blood_group, committed: committed.has(d.id),
      ...scoreDonorMatch({ donor: d, request: r, distanceKm: km, committed: committed.has(d.id) }),
    })).sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
}

/* ---------- meta ---------- */
app.get('/api/meta', (_req, res) => {
  res.json({ groups: BLOOD_GROUPS, compat: CAN_DONATE_TO, geo: Object.fromEntries(Object.entries(GEO).map(([c, l]) => [c, Object.keys(l)])) });
});

app.get('/api/stats', (_req, res) => {
  sweep();
  const one = (sql, ...a) => db.prepare(sql).get(...a).c || 0;
  res.json({
    active_requests: one("SELECT COUNT(*) c FROM requests WHERE status!='closed'"),
    units_open: one("SELECT COALESCE(SUM(units_needed-units_committed),0) c FROM requests WHERE status!='closed'"),
    donors: one('SELECT COUNT(*) c FROM donors'),
    donors_available: db.prepare('SELECT * FROM donors').all().filter(isAvailable).length,
    units_donated: one('SELECT COALESCE(SUM(units),0) c FROM fulfillments WHERE status=\'donated\''),
  });
});

/* ---------- requests ---------- */
app.get('/api/requests', (req, res) => {
  sweep();
  const rows = db.prepare(req.query.closed ? 'SELECT * FROM requests ORDER BY (status=\'closed\'), urgency_deadline ASC'
    : "SELECT * FROM requests WHERE status!='closed' ORDER BY urgency_deadline ASC").all();
  res.json(rows.map(publicRequest));
});

app.post('/api/requests', (req, res) => {
  const b = req.body || {};
  const patient = String(b.patient_name || '').trim(), hospital = String(b.hospital || '').trim();
  const doctor = String(b.doctor_name || '').trim(), contact = String(b.doctor_contact || '').replace(/\D/g, '');
  const units = Number(b.units_needed), deadline = Number(b.urgency_deadline);
  if (patient.length < 2) return bad(res, 'Enter the patient name.');
  if (hospital.length < 3) return bad(res, 'Enter the hospital name.');
  if (!BLOOD_GROUPS.includes(b.blood_group)) return bad(res, 'Choose a valid blood group.');
  if (!Number.isInteger(units) || units < 1 || units > 10) return bad(res, 'Units needed must be between 1 and 10.');
  const coords = coordsOf(b.city, b.locality);
  if (!coords) return bad(res, 'Choose the hospital city and area.');
  if (!Number.isFinite(deadline) || deadline < now() + 10 * MIN) return bad(res, 'Deadline must be at least 10 minutes from now.');
  if (deadline > now() + 24 * HOUR) return bad(res, 'Deadline can be at most 24 hours away. Post a new request if you still need blood after that.');
  if (doctor.length < 3) return bad(res, 'Enter the verifying doctor\'s name.');
  if (!/^\d{10}$/.test(contact.slice(-10)) || contact.length < 10) return bad(res, 'Enter a 10-digit doctor contact number.');
  const token = crypto.randomBytes(6).toString('hex').toUpperCase();
  const info = db.prepare(`INSERT INTO requests (patient_name,hospital,city,locality,lat,lng,blood_group,units_needed,urgency_deadline,
    doctor_name,doctor_contact,note,manage_token,created_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(patient, hospital, b.city, b.locality, coords[0], coords[1], b.blood_group, units, deadline, doctor, contact.slice(-10),
      String(b.note || '').slice(0, 200), token, now(), now() + 24 * HOUR);
  const r = getRequest(info.lastInsertRowid);
  res.status(201).json({ ...publicRequest(r), manage_token: token });
});

app.get('/api/requests/:id', (req, res) => {
  sweep();
  const r = getRequest(req.params.id);
  if (!r) return bad(res, 'Request not found.', 404);
  const responders = db.prepare('SELECT f.id fid, f.status fstatus, f.created_at, f.donated_at, d.* FROM fulfillments f JOIN donors d ON d.id=f.donor_id WHERE f.request_id=? ORDER BY f.id').all(r.id)
    .map((x) => ({ fulfillment_id: x.fid, status: x.fstatus, committed_at: x.created_at, donated_at: x.donated_at, donor: publicDonor(x) }));
  const broadcasts = db.prepare('SELECT COUNT(*) c FROM sms_log WHERE request_id=?').get(r.id).c;
  res.json({ ...publicRequest(r), responders, broadcasts });
});

app.get('/api/requests/:id/matches', (req, res) => {
  sweep();
  const r = getRequest(req.params.id);
  if (!r) return bad(res, 'Request not found.', 404);
  const radius = Math.min(Math.max(Number(req.query.radius) || 25, 1), 100);
  const city = req.query.city || r.city;
  res.json({ eligible_groups: eligibleDonorGroups(r.blood_group), radius, city, donors: findMatches(r, { radius, city }) });
});

// Explainable request prioritization for the dashboard and future dispatch integrations.
app.get('/api/requests/:id/priority', (req, res) => {
  sweep();
  const r = getRequest(req.params.id);
  if (!r) return bad(res, 'Request not found.', 404);
  res.json({ request_id: r.id, status: r.status, priority: scoreRequestPriority(r), generated_at: now() });
});

// "I Can Donate": a donor commits one unit (clinical standard: one unit per donor per donation).
app.post('/api/requests/:id/respond', (req, res) => {
  sweep();
  const r = getRequest(req.params.id), d = getDonor(req.body?.donor_id);
  if (!r) return bad(res, 'Request not found.', 404);
  if (!d) return bad(res, 'Choose a donor identity first.', 401);
  if (r.status === 'closed') return bad(res, 'This request is closed.', 409);
  if (!canDonate(d.blood_group, r.blood_group)) return bad(res, `${d.blood_group} blood is not compatible with ${r.blood_group}.`, 422);
  if (!isAvailable(d)) return bad(res, lockedNow(d) ? 'You are in the 90-day recovery window after a donation.' : 'Turn your availability on first.', 409);
  if (r.units_committed >= r.units_needed) return bad(res, 'All units are already committed. Thank you for offering.', 409);
  if (db.prepare('SELECT 1 FROM fulfillments WHERE request_id=? AND donor_id=?').get(r.id, d.id)) return bad(res, 'You already committed to this request.', 409);
  db.prepare('INSERT INTO fulfillments (request_id,donor_id,units,created_at) VALUES (?,?,1,?)').run(r.id, d.id, now());
  db.prepare('UPDATE requests SET units_committed = units_committed + 1 WHERE id=?').run(r.id);
  recalcStatus(r.id);
  res.json(publicRequest(getRequest(r.id)));
});

// Family actions guarded by the access code: in_transit | received | cancel
app.post('/api/requests/:id/status', (req, res) => {
  sweep();
  const r = getRequest(req.params.id);
  if (!r) return bad(res, 'Request not found.', 404);
  if (String(req.body?.token || '').trim().toUpperCase() !== r.manage_token.toUpperCase()) return bad(res, 'That access code is not correct.', 403);
  if (r.status === 'closed') return bad(res, 'This request is already closed.', 409);
  const action = req.body?.action;
  if (action === 'in_transit') {
    if (r.units_committed < 1) return bad(res, 'At least one donor must respond before blood is in transit.', 409);
    db.prepare("UPDATE requests SET status='in_transit' WHERE id=?").run(r.id);
  } else if (action === 'received') {
    db.prepare("UPDATE requests SET status='closed', closed_reason='received' WHERE id=?").run(r.id);
  } else if (action === 'cancel') {
    db.prepare("UPDATE requests SET status='closed', closed_reason='cancelled' WHERE id=?").run(r.id);
  } else return bad(res, 'Unknown action.');
  res.json(publicRequest(getRequest(r.id)));
});

// Confirm a committed donation (family code OR the donor themself). Starts the 90-day lock.
app.post('/api/fulfillments/:id/confirm', (req, res) => {
  const f = db.prepare('SELECT * FROM fulfillments WHERE id=?').get(Number(req.params.id));
  if (!f) return bad(res, 'Commitment not found.', 404);
  const r = getRequest(f.request_id);
  const byFamily = String(req.body?.token || '').trim().toUpperCase() === r.manage_token.toUpperCase();
  const byDonor = Number(req.body?.donor_id) === f.donor_id;
  if (!byFamily && !byDonor) return bad(res, 'Not allowed.', 403);
  if (f.status === 'donated') return bad(res, 'Already confirmed.', 409);
  const t = now();
  db.prepare("UPDATE fulfillments SET status='donated', donated_at=? WHERE id=?").run(t, f.id);
  db.prepare('UPDATE requests SET units_received = units_received + 1 WHERE id=?').run(r.id);
  db.prepare('UPDATE donors SET last_donation_at=?, locked_until=? WHERE id=?').run(t, t + LOCK_DAYS * 24 * HOUR, f.donor_id);
  res.json({ ok: true });
});

/* ---------- SMS simulator + in-app relay ---------- */
app.post('/api/requests/:id/broadcast', (req, res) => {
  sweep();
  const r = getRequest(req.params.id);
  if (!r) return bad(res, 'Request not found.', 404);
  if (r.status === 'closed') return bad(res, 'This request is closed.', 409);
  const radius = Math.min(Math.max(Number(req.body?.radius) || 25, 1), 100);
  const targets = findMatches(r, { radius, city: req.body?.city || r.city }).filter((m) => !m.committed);
  const ins = db.prepare('INSERT INTO sms_log (request_id,donor_id,body,created_at) VALUES (?,?,?,?)');
  const sent = targets.map((m) => {
    const body = `RedRelay SOS: ${r.units_needed - r.units_committed} unit(s) of ${r.blood_group} needed at ${r.hospital}, ${r.locality}. You are ~${m.distance_km} km away (${m.eta_min} min). Open the app and tap "I Can Donate".`;
    ins.run(r.id, m.id, body, now());
    const d = getDonor(m.id);
    return { donor_id: m.id, to: maskPhone(d.phone), initials: m.initials, blood_group: m.blood_group, distance_km: m.distance_km, body };
  });
  res.json({ count: sent.length, sent });
});

app.get('/api/requests/:id/sms', (req, res) => {
  const rows = db.prepare('SELECT s.*, d.phone, d.initials, d.blood_group FROM sms_log s JOIN donors d ON d.id=s.donor_id WHERE s.request_id=? ORDER BY s.id DESC LIMIT 50').all(Number(req.params.id));
  res.json(rows.map((x) => ({ donor_id: x.donor_id, to: maskPhone(x.phone), initials: x.initials, blood_group: x.blood_group, body: x.body, at: x.created_at })));
});

// Family -> responding donor, through the app. The donor's phone is never revealed.
app.post('/api/requests/:id/relay', (req, res) => {
  const r = getRequest(req.params.id);
  if (!r) return bad(res, 'Request not found.', 404);
  if (String(req.body?.token || '').trim().toUpperCase() !== r.manage_token.toUpperCase()) return bad(res, 'That access code is not correct.', 403);
  const text = String(req.body?.message || '').trim().slice(0, 240);
  if (!text) return bad(res, 'Write a message first.');
  if (!db.prepare('SELECT 1 FROM fulfillments WHERE request_id=? AND donor_id=?').get(r.id, Number(req.body?.donor_id))) return bad(res, 'You can only message donors who responded.', 409);
  db.prepare('INSERT INTO relay_messages (request_id,donor_id,text,created_at) VALUES (?,?,?,?)').run(r.id, Number(req.body.donor_id), text, now());
  res.status(201).json({ ok: true });
});

/* ---------- donors ---------- */
app.get('/api/donors', (req, res) => {
  const rows = db.prepare('SELECT * FROM donors ORDER BY id').all().map(publicDonor);
  const { group, city } = req.query;
  res.json(rows.filter((d) => (!group || d.blood_group === group) && (!city || d.city === city)));
});

app.post('/api/donors', (req, res) => {
  const b = req.body || {};
  const name = String(b.name || '').trim(), phone = String(b.phone || '').replace(/\D/g, '').slice(-10);
  if (name.length < 2) return bad(res, 'Enter your name.');
  if (phone.length !== 10) return bad(res, 'Enter a 10-digit mobile number.');
  if (!BLOOD_GROUPS.includes(b.blood_group)) return bad(res, 'Choose your blood group.');
  const c = coordsOf(b.city, b.locality);
  if (!c) return bad(res, 'Choose your city and locality.');
  if (!b.healthy) return bad(res, 'Please confirm the health declaration.');
  const t = now();
  const info = db.prepare(`INSERT INTO donors (name,initials,phone,blood_group,city,locality,lat,lng,available,created_at) VALUES (?,?,?,?,?,?,?,?,1,?)`)
    .run(name, initialsOf(name), phone, b.blood_group, b.city, b.locality, c[0], c[1], t);
  res.status(201).json(publicDonor(getDonor(info.lastInsertRowid)));
});

// Donor's own dashboard (still masks the phone, shows only the last 2 digits).
app.get('/api/donors/:id', (req, res) => {
  const d = getDonor(req.params.id);
  if (!d) return bad(res, 'Donor not found.', 404);
  const history = db.prepare(`SELECT f.id fulfillment_id, f.status, f.created_at, f.donated_at, r.id request_id, r.hospital, r.locality, r.blood_group, r.status request_status
    FROM fulfillments f JOIN requests r ON r.id=f.request_id WHERE f.donor_id=? ORDER BY f.id DESC`).all(d.id);
  res.json({ ...publicDonor(d), name: d.name, phone_masked: maskPhone(d.phone), last_donation_at: d.last_donation_at, history });
});

app.patch('/api/donors/:id/availability', (req, res) => {
  const d = getDonor(req.params.id);
  if (!d) return bad(res, 'Donor not found.', 404);
  const want = !!req.body?.available;
  if (want && lockedNow(d)) return bad(res, 'You are locked for 90 days after a confirmed donation. This protects your health.', 409);
  db.prepare('UPDATE donors SET available=? WHERE id=?').run(want ? 1 : 0, d.id);
  res.json(publicDonor(getDonor(d.id)));
});

app.get('/api/donors/:id/alerts', (req, res) => {
  sweep();
  const d = getDonor(req.params.id);
  if (!d) return bad(res, 'Donor not found.', 404);
  const open = db.prepare("SELECT * FROM requests WHERE status!='closed' ORDER BY urgency_deadline").all();
  const mine = new Set(db.prepare('SELECT request_id FROM fulfillments WHERE donor_id=?').all(d.id).map((x) => x.request_id));
  const alerts = open.filter((r) => canDonate(d.blood_group, r.blood_group)).map((r) => {
    const km = haversineKm(r.lat, r.lng, d.lat, d.lng);
    return { ...publicRequest(r), distance_km: Math.round(km * 10) / 10, eta_min: etaMinutes(km), already_committed: mine.has(r.id) };
  }).filter((a) => a.distance_km <= 40 || a.already_committed);
  res.json(alerts);
});

app.get('/api/donors/:id/inbox', (req, res) => {
  const rows = db.prepare(`SELECT m.id, m.text, m.created_at, r.hospital, r.id request_id FROM relay_messages m JOIN requests r ON r.id=m.request_id WHERE m.donor_id=? ORDER BY m.id DESC LIMIT 30`).all(Number(req.params.id));
  res.json(rows);
});

/* ---------- serve built frontend in production ---------- */
const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '../client/dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^(?!\/api).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

// Consistent error response; never leak stack traces or database internals to clients.
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  if (err?.message === 'Origin not allowed by CORS policy') return res.status(403).json({ error: 'Origin not allowed.' });
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) return res.status(400).json({ error: 'Invalid JSON body.' });
  console.error('API error:', err?.message || 'unknown error');
  res.status(500).json({ error: 'Unexpected server error. Please try again.' });
});

// Periodically prune expired rate-limit buckets to keep memory bounded.
setInterval(() => { const t = now(); for (const [k, b] of rateBuckets) if (t - b.start > 120_000) rateBuckets.delete(k); }, 120_000).unref();


const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`RedRelay API on http://localhost:${PORT}`));
