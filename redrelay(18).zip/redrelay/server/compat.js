// Clinical ABO/Rh red-cell compatibility matrix.
// Key = DONOR group, value = recipient groups that donor can give red cells to.
export const CAN_DONATE_TO = {
  'O-': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
  'O+': ['O+', 'A+', 'B+', 'AB+'],
  'A-': ['A-', 'A+', 'AB-', 'AB+'],
  'A+': ['A+', 'AB+'],
  'B-': ['B-', 'B+', 'AB-', 'AB+'],
  'B+': ['B+', 'AB+'],
  'AB-': ['AB-', 'AB+'],
  'AB+': ['AB+'],
};
export const BLOOD_GROUPS = Object.keys(CAN_DONATE_TO);
export const canDonate = (donor, recipient) => !!CAN_DONATE_TO[donor] && CAN_DONATE_TO[donor].includes(recipient);
export const eligibleDonorGroups = (recipient) => BLOOD_GROUPS.filter((d) => canDonate(d, recipient));
