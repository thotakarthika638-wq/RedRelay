import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreDonorMatch, scoreRequestPriority } from '../matching.js';

const request = { blood_group: 'A+', urgency_deadline: 1_000_000 };
const donor = { blood_group: 'A+', available: true };

test('donor ranking returns explainable score and tier', () => {
  const match = scoreDonorMatch({ donor, request, distanceKm: 3, committed: false, now: 900_000 });
  assert.equal(match.tier, 'Priority');
  assert.ok(match.score >= 80 && match.score <= 100);
  assert.ok(match.reasons.includes('Exact blood-group match'));
});

test('incompatible donor is rejected by ranking engine', () => {
  assert.equal(scoreDonorMatch({ donor: { blood_group: 'B-', available: true }, request, distanceKm: 2 }), null);
});

test('already committed donor is ranked lower than equivalent uncommitted donor', () => {
  const free = scoreDonorMatch({ donor, request, distanceKm: 5, committed: false, now: 900_000 });
  const committed = scoreDonorMatch({ donor, request, distanceKm: 5, committed: true, now: 900_000 });
  assert.ok(free.score > committed.score);
});

test('request priority increases with shorter deadline and larger shortage', () => {
  const low = scoreRequestPriority({ units_needed: 1, units_committed: 0, urgency_deadline: 86_400_000 }, 0);
  const high = scoreRequestPriority({ units_needed: 5, units_committed: 0, urgency_deadline: 3_600_000 }, 0);
  assert.ok(high.score > low.score);
  assert.equal(high.remaining_units, 5);
  assert.ok(high.breakdown.deadline >= 0 && high.breakdown.shortage >= 0);
});
