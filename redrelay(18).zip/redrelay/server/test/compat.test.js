import test from 'node:test';
import assert from 'node:assert/strict';
import { BLOOD_GROUPS, canDonate, eligibleDonorGroups } from '../compat.js';

test('blood group matrix contains all eight groups', () => {
  assert.equal(BLOOD_GROUPS.length, 8);
});

test('O negative is compatible with all recipient groups', () => {
  for (const group of BLOOD_GROUPS) assert.equal(canDonate('O-', group), true);
});

test('AB positive can receive from every donor group', () => {
  assert.deepEqual(eligibleDonorGroups('AB+'), BLOOD_GROUPS);
});

test('AB negative recipients only accept negative donor groups of compatible ABO type', () => {
  assert.deepEqual(eligibleDonorGroups('AB-'), ['O-', 'A-', 'B-', 'AB-']);
});

test('invalid blood groups never match', () => {
  assert.equal(canDonate('invalid', 'AB+'), false);
  assert.deepEqual(eligibleDonorGroups('invalid'), []);
});
