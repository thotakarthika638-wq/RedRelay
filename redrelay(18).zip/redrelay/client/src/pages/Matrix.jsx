import { CAN_DONATE_TO, GROUPS } from '../lib/compat.js';
import BloodTag from '../components/BloodTag.jsx';
import { useState } from 'react';

export default function Matrix() {
  const [sel, setSel] = useState('B+');
  const donors = GROUPS.filter((d) => CAN_DONATE_TO[d].includes(sel));
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-black">Who can give to whom</h1>
        <p className="mt-1 max-w-2xl text-mute">The same ABO/Rh red-cell matrix the matching engine runs on every SOS. Pick a patient group to see the donor pool.</p>
      </div>
      <div className="panel p-5">
        <p className="lbl">Patient group</p>
        <div className="flex flex-wrap gap-2">{GROUPS.map((g) => <button key={g} onClick={() => setSel(g)} aria-pressed={sel === g} className={`rounded p-0.5 ${sel === g ? 'ring-2 ring-blood ring-offset-2 ring-offset-label' : ''}`}><BloodTag group={g} size="lg" /></button>)}</div>
        <p className="mt-5 text-lg font-bold">Eligible donors for {sel}:</p>
        <div className="mt-2 flex flex-wrap gap-2">{donors.map((g) => <BloodTag key={g} group={g} size="lg" />)}</div>
      </div>
      <div className="panel overflow-x-auto p-5">
        <table className="w-full min-w-[520px] text-center">
          <caption className="pb-3 text-left text-sm text-mute">Rows are donors, columns are patients. A filled cell means the donor can give.</caption>
          <thead><tr><th className="p-2 text-left text-sm text-mute">Donor ↓ / Patient →</th>{GROUPS.map((g) => <th key={g} className="p-1"><BloodTag group={g} size="xs" /></th>)}</tr></thead>
          <tbody>
            {GROUPS.map((d) => (
              <tr key={d} className="border-t border-rule">
                <th className="p-2 text-left"><BloodTag group={d} size="sm" /></th>
                {GROUPS.map((r) => <td key={r} className={`p-2 ${r === sel ? 'bg-blood-soft' : ''}`}>{CAN_DONATE_TO[d].includes(r) ? <span className="inline-block h-4 w-4 rounded-sm bg-ink" aria-label="can donate" /> : <span className="text-rule" aria-label="cannot donate">·</span>}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
