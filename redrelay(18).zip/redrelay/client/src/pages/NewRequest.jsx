import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Siren, ShieldCheck } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, saveToken } from '../lib/ctx.jsx';
import { GROUPS, eligibleDonorGroups } from '../lib/compat.js';
import BloodTag from '../components/BloodTag.jsx';

const HOURS = [2, 4, 6, 12, 24];

export default function NewRequest() {
  const { meta, notify } = useApp();
  const nav = useNavigate();
  const [f, setF] = useState({ patient_name: '', hospital: '', city: 'Hyderabad', locality: '', blood_group: 'B+', units_needed: 2, hours: 4, custom: '', doctor_name: '', doctor_contact: '', note: '', genuine: false });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const areas = meta?.geo[f.city] || [];
  const eligible = useMemo(() => eligibleDonorGroups(f.blood_group), [f.blood_group]);

  const deadline = () => (f.custom ? new Date(f.custom).getTime() : Date.now() + f.hours * 3600e3);

  function validate() {
    const e = {}, d = deadline();
    if (f.patient_name.trim().length < 2) e.patient_name = 'Enter the patient name.';
    if (f.hospital.trim().length < 3) e.hospital = 'Enter the hospital name.';
    if (!f.locality) e.locality = 'Choose the hospital area.';
    if (!(f.units_needed >= 1 && f.units_needed <= 10)) e.units_needed = 'Units must be between 1 and 10.';
    if (!Number.isFinite(d) || d < Date.now() + 10 * 60e3) e.deadline = 'Deadline must be at least 10 minutes from now.';
    else if (d > Date.now() + 24 * 3600e3) e.deadline = 'Deadline can be at most 24 hours away.';
    if (f.doctor_name.trim().length < 3) e.doctor_name = 'Enter the verifying doctor\'s name.';
    if (f.doctor_contact.replace(/\D/g, '').length < 10) e.doctor_contact = 'Enter a 10-digit doctor contact number.';
    if (!f.genuine) e.genuine = 'Please confirm this request is genuine.';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function submit(ev) {
    ev.preventDefault();
    if (!validate()) return;
    setBusy(true);
    try {
      const r = await api.createRequest({ ...f, units_needed: Number(f.units_needed), urgency_deadline: deadline() });
      saveToken(r.id, r.manage_token);
      notify(`SOS broadcast. Your family access code is ${r.manage_token}.`);
      nav(`/sos/${r.id}`, { state: { justCreated: r.manage_token } });
    } catch (err) { notify(err.message, 'err'); } finally { setBusy(false); }
  }
  const Err = ({ k }) => (errors[k] ? <p className="mt-1 text-sm font-semibold text-blood" role="alert">{errors[k]}</p> : null);

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
      <form onSubmit={submit} noValidate className="panel space-y-6 p-6">
        <div>
          <h1 className="text-3xl font-black">Raise an emergency blood SOS</h1>
          <p className="mt-1 text-mute">It goes live on the feed immediately and expires automatically after 24 hours.</p>
        </div>

        <fieldset>
          <legend className="lbl">Patient blood group</legend>
          <div className="flex flex-wrap gap-2">
            {GROUPS.map((g) => (
              <button type="button" key={g} onClick={() => setF({ ...f, blood_group: g })} aria-pressed={f.blood_group === g} className={`rounded p-0.5 ${f.blood_group === g ? 'ring-2 ring-blood ring-offset-2 ring-offset-label' : ''}`}>
                <BloodTag group={g} size="lg" />
              </button>
            ))}
          </div>
        </fieldset>

        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="lbl" htmlFor="pn">Patient name</label><input id="pn" className="field" value={f.patient_name} onChange={set('patient_name')} placeholder="Full name" /><Err k="patient_name" /></div>
          <div><label className="lbl" htmlFor="un">Units needed</label><input id="un" type="number" min="1" max="10" className="field" value={f.units_needed} onChange={set('units_needed')} /><Err k="units_needed" /></div>
          <div className="sm:col-span-2"><label className="lbl" htmlFor="hn">Hospital</label><input id="hn" className="field" value={f.hospital} onChange={set('hospital')} placeholder="e.g. Apollo Hospital" /><Err k="hospital" /></div>
          <div>
            <label className="lbl" htmlFor="ct">City</label>
            <select id="ct" className="field" value={f.city} onChange={(e) => setF({ ...f, city: e.target.value, locality: '' })}>
              {meta && Object.keys(meta.geo).map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="lbl" htmlFor="lc">Hospital area</label>
            <select id="lc" className="field" value={f.locality} onChange={set('locality')}><option value="">Choose area</option>{areas.map((a) => <option key={a}>{a}</option>)}</select>
            <Err k="locality" />
          </div>
        </div>

        <fieldset>
          <legend className="lbl">Blood needed within</legend>
          <div className="flex flex-wrap items-center gap-2">
            {HOURS.map((h) => (
              <button type="button" key={h} onClick={() => setF({ ...f, hours: h, custom: '' })} aria-pressed={!f.custom && f.hours === h}
                className={`rounded-md border px-3 py-2 font-display font-bold ${!f.custom && f.hours === h ? 'border-blood bg-blood text-white' : 'border-rule bg-label hover:border-ink'}`}>{h} hours</button>
            ))}
            <span className="px-1 text-sm text-mute">or</span>
            <input type="datetime-local" className="field !w-auto" value={f.custom} onChange={set('custom')} aria-label="Custom deadline" />
          </div>
          <Err k="deadline" />
        </fieldset>

        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="lbl" htmlFor="dn">Verifying doctor</label><input id="dn" className="field" value={f.doctor_name} onChange={set('doctor_name')} placeholder="Dr. name" /><Err k="doctor_name" /></div>
          <div><label className="lbl" htmlFor="dc">Doctor contact</label><input id="dc" inputMode="tel" className="field" value={f.doctor_contact} onChange={set('doctor_contact')} placeholder="10-digit mobile" /><Err k="doctor_contact" /></div>
          <div className="sm:col-span-2"><label className="lbl" htmlFor="nt">Clinical note (optional)</label><input id="nt" maxLength={200} className="field" value={f.note} onChange={set('note')} placeholder="e.g. Emergency surgery, trauma, childbirth" /></div>
        </div>

        <div>
          <label className="flex items-start gap-3 text-sm"><input type="checkbox" className="mt-1" checked={f.genuine} onChange={set('genuine')} />I confirm this is a genuine emergency and the doctor above can verify it.</label>
          <Err k="genuine" />
        </div>
        <button className="btn btn-blood w-full text-lg" disabled={busy}><Siren size={20} />{busy ? 'Broadcasting…' : 'Broadcast SOS'}</button>
      </form>

      <aside className="space-y-4 lg:sticky lg:top-6 lg:self-start">
        <div className="panel p-5">
          <h2 className="text-lg font-extrabold">Who can give to {f.blood_group}?</h2>
          <p className="mt-1 text-sm text-mute">Donor groups the matching engine will search:</p>
          <div className="mt-3 flex flex-wrap gap-2">{GROUPS.map((g) => <BloodTag key={g} group={g} size="md" dim={!eligible.includes(g)} />)}</div>
          <p className="mt-3 text-sm">{eligible.length} of 8 groups are compatible{f.blood_group === 'AB+' ? ' (universal recipient)' : f.blood_group === 'O-' ? ' (only O− can give)' : ''}.</p>
        </div>
        <div className="panel flex gap-3 p-5 text-sm">
          <ShieldCheck className="mt-0.5 shrink-0 text-saline" />
          <p>The doctor's number stays private (only the last two digits are shown). The patient's name is shortened on the public feed.</p>
        </div>
      </aside>
    </div>
  );
}
