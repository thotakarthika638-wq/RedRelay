import { useCallback, useEffect, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { ArrowLeft, BadgeCheck, Check, Clock, KeyRound, MapPin, MessageSquare, Radio, Send, Truck } from 'lucide-react';
import { api } from '../lib/api.js';
import { saveToken, tokenFor, useApp } from '../lib/ctx.jsx';
import { canDonate, GROUPS } from '../lib/compat.js';
import { countdown, isCritical, useInterval, useNow, ago } from '../lib/time.js';
import BloodTag, { ISBT } from '../components/BloodTag.jsx';
import Bag from '../components/Bag.jsx';
import Stepper from '../components/Stepper.jsx';
import MapView from '../components/MapView.jsx';
import { abo } from '../lib/compat.js';

export default function RequestDetail() {
  const { id } = useParams();
  const { state } = useLocation();
  const { me, notify, meta, refreshDonors } = useApp();
  const now = useNow();
  const [r, setR] = useState(null), [err, setErr] = useState('');
  const [radius, setRadius] = useState(25), [city, setCity] = useState('');
  const [m, setM] = useState(null);
  const [token, setToken] = useState(tokenFor(id)), [codeInput, setCodeInput] = useState('');
  const [sms, setSms] = useState([]);
  const [relay, setRelay] = useState({ to: null, text: '' });
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => api.request(id).then((x) => { setR(x); setErr(''); }).catch((e) => setErr(e.message)), [id]);
  useEffect(() => { load(); api.smsLog(id).then(setSms).catch(() => {}); }, [load, id]);
  useInterval(load, 4000);
  useEffect(() => { if (r && !city) setCity(r.city); }, [r, city]);
  useEffect(() => { setToken(tokenFor(id)); }, [id]);

  const rc = r?.units_committed, rs = r?.status;
  useEffect(() => { if (r && city) api.matches(id, radius, city).then(setM).catch(() => {}); }, [id, radius, city, rc, rs]); // eslint-disable-line

  if (err && !r) return <div className="panel p-8"><p className="font-bold">{err}</p><Link to="/" className="btn btn-line mt-4">Back to the feed</Link></div>;
  if (!r) return <p className="text-mute">Loading request…</p>;

  const closed = r.status === 'closed', crit = isCritical(r, now);
  const mine = me && r.responders.find((x) => x.donor.id === me.id);
  const full = r.units_committed >= r.units_needed;
  const manager = !!token;

  const run = async (fn, okMsg) => {
    setBusy(true);
    try { await fn(); if (okMsg) notify(okMsg); await load(); refreshDonors(); }
    catch (e) { notify(e.message, 'err'); } finally { setBusy(false); }
  };
  const donate = () => run(() => api.respond(r.id, me.id), 'You committed one unit. Thank you.');
  const status = (action, msg) => run(() => api.setStatus(r.id, token, action), msg);
  const confirm = (fid, body) => run(() => api.confirm(fid, body), 'Donation confirmed. Donor is locked for 90 days.');
  const sendRelay = () => run(async () => { await api.relay(r.id, { token, donor_id: relay.to, message: relay.text }); setRelay({ to: null, text: '' }); }, 'Message sent through the relay.');
  const broadcast = () => run(async () => { const out = await api.broadcast(r.id, radius, city); setSms(await api.smsLog(r.id)); notify(`${out.count} simulated SMS alerts sent.`); });
  const enterCode = () => { saveToken(id, codeInput.trim().toUpperCase()); setToken(codeInput.trim().toUpperCase()); setCodeInput(''); };

  const eligible = m?.donors || [];
  const mapDonors = eligible.filter((d) => d.lat);

  return (
    <div className="space-y-6">
      <Link to="/" className="inline-flex items-center gap-1 text-sm font-semibold text-mute hover:text-ink"><ArrowLeft size={16} />All requests</Link>

      {state?.justCreated && (
        <div className="flex flex-wrap items-center gap-4 rounded-lg border-2 border-ink bg-amber-soft p-4">
          <KeyRound className="shrink-0" />
          <div className="min-w-0 flex-1"><p className="font-bold">Save your family access code</p><p className="text-sm">You need it to message donors and to mark blood received. It is stored on this device too.</p></div>
          <span className="rounded bg-ink px-4 py-2 font-mono text-2xl font-bold tracking-widest text-white">{state.justCreated}</span>
        </div>
      )}

      <section className={`overflow-hidden rounded-xl border-2 bg-label ${crit && !closed ? 'border-blood animate-sos' : 'border-ink'}`}>
        <div className="grid md:grid-cols-[auto_1fr_auto]">
          <div className="flex flex-col items-center justify-center gap-2 border-b-2 border-dashed border-ink/25 p-6 md:border-b-0 md:border-r-2" style={{ background: ISBT[abo(r.blood_group)] }}>
            <BloodTag group={r.blood_group} size="xl" className="!border-0 !bg-transparent" />
            <p className="font-bold">{r.units_needed} unit{r.units_needed > 1 ? 's' : ''} needed</p>
          </div>
          <div className="p-6">
            {crit && !closed && <p className="mb-2 inline-flex items-center gap-2 rounded bg-blood px-2 py-1 text-xs font-bold text-white"><span className="h-2 w-2 rounded-full bg-white animate-pulse" />Critical, under 4 hours</p>}
            <h1 className="text-3xl font-black leading-tight">{r.hospital}</h1>
            <p className="mt-1 flex items-center gap-1 text-mute"><MapPin size={16} />{r.locality}, {r.city} · patient {r.patient}</p>
            {r.note && <p className="mt-3 max-w-xl">{r.note}</p>}
            <p className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
              <span className="flex items-center gap-1 font-semibold text-saline"><BadgeCheck size={16} />Verified by {r.doctor_name}</span>
              <span className="font-mono text-mute">{r.doctor_contact_masked}</span>
            </p>
          </div>
          <div className="flex items-center gap-5 border-t border-rule p-6 md:border-l md:border-t-0">
            <Bag committed={r.units_committed} needed={r.units_needed} received={r.units_received} size={72} />
            <div>
              <p className="font-display text-5xl font-black leading-none tabular-nums">{r.units_committed}/{r.units_needed}</p>
              <p className="font-bold">units committed</p>
              <p className="text-sm text-mute">{r.units_received} donated so far</p>
              <p className={`mt-2 flex items-center gap-1 font-mono text-lg font-bold ${crit && !closed ? 'text-blood' : ''}`}><Clock size={16} />{closed ? 'Closed' : countdown(r.urgency_deadline, now)}</p>
            </div>
          </div>
        </div>
        <div className="border-t border-rule bg-paper/60 p-5"><Stepper status={r.status} reason={r.closed_reason} /></div>
      </section>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <section className="panel p-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className="text-xl font-black">Compatible donors nearby</h2>
                <p className="text-sm text-mute">Eligible groups for {r.blood_group}:</p>
                <div className="mt-1 flex flex-wrap gap-1.5">{GROUPS.map((g) => <BloodTag key={g} group={g} size="sm" dim={!r.eligible_groups.includes(g)} />)}</div>
              </div>
              <div className="flex flex-wrap items-end gap-3">
                <div><label className="lbl !mb-1 text-xs" htmlFor="cf">City</label>
                  <select id="cf" className="field !w-auto !py-1.5 text-sm" value={city} onChange={(e) => setCity(e.target.value)}>
                    <option value="all">All cities</option>{meta && Object.keys(meta.geo).map((c) => <option key={c}>{c}</option>)}
                  </select></div>
                <div><label className="lbl !mb-1 text-xs" htmlFor="rf">Radius: {radius} km</label>
                  <input id="rf" type="range" min="2" max="50" value={radius} onChange={(e) => setRadius(Number(e.target.value))} className="w-36 accent-blood" /></div>
              </div>
            </div>

            <ul className="mt-4 divide-y divide-rule">
              {eligible.length === 0 && <li className="py-8 text-center text-mute">No available compatible donors in this area. Widen the radius or switch city.</li>}
              {eligible.map((d) => {
                const resp = r.responders.find((x) => x.donor.id === d.id);
                return (
                  <li key={d.id} className="py-3">
                    <div className="flex flex-wrap items-center gap-3">
                      <BloodTag group={d.blood_group} size="md" />
                      <div className="min-w-0 flex-1">
                        <p className="font-display font-extrabold">{d.initials} <span className="font-sans text-sm font-normal text-mute">· {d.locality}</span></p>
                        <p className="text-sm text-mute">{d.distance_km} km · ~{d.eta_min} min drive · {d.exact_match ? 'exact match' : 'compatible'}</p>
                        <p className="mt-1 text-xs text-mute">Smart match: {d.score ?? '—'}/100 · {d.tier || 'Eligible'}{d.reasons?.length ? ` · ${d.reasons.join(' · ')}` : ''}</p>
                      </div>
                      {resp ? (
                        <span className={`rounded px-2 py-1 text-xs font-bold ${resp.status === 'donated' ? 'bg-ink text-white' : 'bg-blood-soft text-blood-dark'}`}>{resp.status === 'donated' ? 'Donated' : 'Committed'}</span>
                      ) : <span className="font-mono text-xs text-mute">•••• ••••••</span>}
                      {manager && resp && !closed && (
                        <>
                          <button className="btn btn-line btn-sm" onClick={() => setRelay(relay.to === d.id ? { to: null, text: '' } : { to: d.id, text: '' })}><MessageSquare size={14} />Relay</button>
                          {resp.status !== 'donated' && <button className="btn btn-ink btn-sm" disabled={busy} onClick={() => confirm(resp.fulfillment_id, { token })}><Check size={14} />Donated</button>}
                        </>
                      )}
                    </div>
                    {relay.to === d.id && (
                      <div className="mt-2 flex gap-2">
                        <input className="field" maxLength={240} placeholder="e.g. Ward 3, ask for Dr. Mehta at the blood bank" value={relay.text} onChange={(e) => setRelay({ ...relay, text: e.target.value })} aria-label="Message for donor" />
                        <button className="btn btn-blood btn-sm" disabled={busy || !relay.text.trim()} onClick={sendRelay}><Send size={14} />Send</button>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </section>

          <section>
            <h2 className="mb-2 text-xl font-black">Hospital route map</h2>
            <MapView hospital={{ lat: r.lat, lng: r.lng, name: r.hospital }} donors={mapDonors} radius={radius} />
            <p className="mt-2 text-xs text-mute">Donor pins are approximate (about 1 km) to protect privacy. Drive times are estimates for city traffic. Solid red lines are donors who committed.</p>
          </section>
        </div>

        <aside className="space-y-6">
          <section className="panel p-5">
            <h2 className="text-lg font-extrabold">Can you donate?</h2>
            {closed ? <p className="mt-2 text-mute">This request is closed. Thank you for checking.</p>
              : !me ? <p className="mt-2 text-sm text-mute">Choose a donor in "Demo identity" at the top, or <Link className="font-bold text-blood underline" to="/donors">register as a donor</Link>.</p>
              : !canDonate(me.blood_group, r.blood_group) ? <p className="mt-2 text-sm">{me.initials} ({me.blood_group}) can't give to {r.blood_group}. Switch identity to one of the highlighted groups.</p>
              : mine?.status === 'donated' ? (<div className="mt-2"><p className="font-bold text-saline">Donation confirmed. You saved a life.</p><Link to="/me" className="btn btn-ink btn-sm mt-3">Get your certificate</Link></div>)
              : mine ? (<div className="mt-2 space-y-3"><p className="font-bold text-blood">You committed one unit.</p><p className="text-sm text-mute">Head to {r.hospital}. Confirm below once you've donated.</p><button className="btn btn-ink w-full" disabled={busy} onClick={() => confirm(mine.fulfillment_id, { donor_id: me.id })}><Check size={18} />I've donated</button></div>)
              : full ? <p className="mt-2 text-mute">All units are committed. Thank you for offering.</p>
              : (<div className="mt-2 space-y-3"><p className="text-sm text-mute">As {me.initials} ({me.blood_group}) in {me.locality}. Your number stays hidden.</p>
                  <button className="btn btn-blood w-full text-lg" disabled={busy || !me.available} onClick={donate}><Truck size={20} />I Can Donate</button>
                  {!me.available && <p className="text-sm font-semibold text-amber">{me.locked_until ? 'You are in the 90-day recovery window.' : 'Your availability is off.'}</p>}</div>)}
          </section>

          <section className="panel p-5">
            <h2 className="text-lg font-extrabold">Patient family</h2>
            {!manager ? (
              <div className="mt-2 space-y-2"><p className="text-sm text-mute">Enter your access code to manage this request.</p>
                <div className="flex gap-2"><input className="field font-mono uppercase" placeholder="Access code" value={codeInput} onChange={(e) => setCodeInput(e.target.value)} aria-label="Family access code" /><button className="btn btn-ink btn-sm" disabled={!codeInput.trim()} onClick={enterCode}>Unlock</button></div>
                <p className="text-xs text-mute">Demo requests use codes demo-1 to demo-5.</p></div>
            ) : closed ? <p className="mt-2 text-sm text-mute">Request closed.</p> : (
              <div className="mt-3 space-y-2">
                {r.status !== 'in_transit' && r.units_committed > 0 && <button className="btn btn-line w-full" disabled={busy} onClick={() => status('in_transit', 'Marked as in transit.')}><Truck size={18} />Mark in transit</button>}
                <button className="btn btn-ink w-full" disabled={busy} onClick={() => status('received', 'Closed. Thank you, donors.')}><Check size={18} />Mark blood received</button>
                <button className="w-full text-sm font-semibold text-blood underline" disabled={busy} onClick={() => status('cancel', 'Request cancelled.')}>Cancel request</button>
                <p className="text-xs text-mute">Closing stops new alerts so the request doesn't linger after blood is secured.</p>
              </div>
            )}
          </section>

          <section className="rounded-lg border border-ink bg-ink p-5 text-white">
            <h2 className="flex items-center gap-2 text-lg font-extrabold"><Radio size={18} />SMS SOS dispatch (simulated)</h2>
            <p className="mt-1 text-sm text-white/70">Sends an alert to every available compatible donor within {radius} km{city && city !== 'all' ? ` in ${city}` : ''}.</p>
            <button className="btn mt-3 w-full bg-white text-ink hover:bg-white/90" disabled={busy || closed} onClick={broadcast}><Send size={16} />Dispatch SOS alerts</button>
            <ul className="mt-3 max-h-64 space-y-2 overflow-y-auto font-mono text-xs">
              {sms.length === 0 && <li className="text-white/50">No messages dispatched yet.</li>}
              {sms.slice(0, 12).map((s, i) => <li key={i} className="rounded bg-white/10 p-2"><span className="text-amber">to {s.initials} {s.to}</span> <span className="text-white/50">{ago(s.at, now)}</span><br />{s.body}</li>)}
            </ul>
          </section>
        </aside>
      </div>
    </div>
  );
}
