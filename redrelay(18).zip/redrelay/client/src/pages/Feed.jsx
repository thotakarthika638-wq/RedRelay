import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Siren, UserPlus } from 'lucide-react';
import { api } from '../lib/api.js';
import { useInterval, useNow, countdown, isCritical } from '../lib/time.js';
import { GROUPS } from '../lib/compat.js';
import SosCard from '../components/SosCard.jsx';
import BloodTag from '../components/BloodTag.jsx';
import Bag from '../components/Bag.jsx';
import { useApp } from '../lib/ctx.jsx';

function Spotlight({ r }) {
  const now = useNow();
  if (!r) return null;
  return (
    <Link to={`/sos/${r.id}`} className="group block rounded-xl border-2 border-ink bg-label p-5 shadow-[6px_6px_0_0_#0E1B2C] transition hover:-translate-y-0.5">
      <div className="flex items-center justify-between text-xs font-bold text-blood">
        <span className="flex items-center gap-2"><span className="relative flex h-2.5 w-2.5"><span className="absolute h-full w-full rounded-full bg-blood animate-ping2" /><span className="h-2.5 w-2.5 rounded-full bg-blood" /></span>Most urgent right now</span>
        <span className="font-mono text-base text-ink">{countdown(r.urgency_deadline, now)}</span>
      </div>
      <div className="mt-4 flex items-center gap-5">
        <Bag committed={r.units_committed} needed={r.units_needed} received={r.units_received} size={64} />
        <div className="min-w-0">
          <div className="flex items-center gap-3"><BloodTag group={r.blood_group} size="xl" /></div>
          <p className="mt-2 truncate text-lg font-extrabold">{r.hospital}</p>
          <p className="text-sm text-mute">{r.locality}, {r.city}</p>
        </div>
      </div>
      <p className="mt-4 border-t border-dashed border-ink/30 pt-3 font-display text-xl font-extrabold">
        <span className="tabular-nums">{r.units_committed}/{r.units_needed}</span> units committed
        <span className="ml-2 text-sm font-semibold text-mute">{r.units_needed - r.units_committed > 0 ? `${r.units_needed - r.units_committed} donors still needed` : 'covered, awaiting arrival'}</span>
      </p>
      <div className="barcode mt-3 h-6 opacity-70" aria-hidden="true" />
    </Link>
  );
}

export default function Feed() {
  const [reqs, setReqs] = useState(null);
  const [group, setGroup] = useState('');
  const [city, setCity] = useState('');
  const [showClosed, setShowClosed] = useState(false);
  const { meta } = useApp();

  const load = useCallback(() => api.requests(showClosed).then(setReqs).catch(() => setReqs([])), [showClosed]);
  useEffect(() => { load(); }, [load]);
  useInterval(load, 5000); // live feed: poll every 5 s

  const list = useMemo(() => (reqs || []).filter((r) => (!group || r.blood_group === group) && (!city || r.city === city)), [reqs, group, city]);
  const spotlight = useMemo(() => (reqs || []).filter((r) => r.status !== 'closed' && r.units_committed < r.units_needed).sort((a, b) => a.urgency_deadline - b.urgency_deadline)[0], [reqs]);
  const crit = (reqs || []).filter((r) => isCritical(r)).length;

  return (
    <div>
      <section className="grid items-center gap-8 lg:grid-cols-[1.15fr_.85fr]">
        <div>
          <h1 className="text-4xl font-black leading-[1.02] tracking-tight sm:text-6xl" style={{ fontStretch: '108%' }}>
            The right blood group,<br />found before the clock runs out.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-ink/80">
            Families post a doctor-verified SOS. RedRelay matches it against compatible donors nearby using the clinical ABO/Rh matrix, and nobody's phone number is ever exposed.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/sos/new" className="btn btn-blood"><Siren size={18} />Raise an SOS</Link>
            <Link to="/donors" className="btn btn-line"><UserPlus size={18} />Register as a donor</Link>
          </div>
        </div>
        <Spotlight r={spotlight} />
      </section>

      <section className="mt-12">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-2xl font-black">Emergency broadcast feed</h2>
            <p className="text-sm text-mute">{reqs ? `${list.length} request${list.length === 1 ? '' : 's'}${crit ? `, ${crit} critical (under 4 hours)` : ''}. Updates every few seconds.` : 'Loading…'}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select className="field !w-auto !py-1.5 text-sm" value={city} onChange={(e) => setCity(e.target.value)} aria-label="Filter by city">
              <option value="">All cities</option>
              {meta && Object.keys(meta.geo).map((c) => <option key={c}>{c}</option>)}
            </select>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={showClosed} onChange={(e) => setShowClosed(e.target.checked)} />Show closed</label>
          </div>
        </div>
        <div className="mb-5 flex flex-wrap gap-1.5" role="group" aria-label="Filter by patient blood group">
          <button onClick={() => setGroup('')} className={`rounded border px-2.5 py-1 text-sm font-bold ${!group ? 'border-ink bg-ink text-white' : 'border-rule bg-label'}`}>All groups</button>
          {GROUPS.map((g) => (
            <button key={g} onClick={() => setGroup(group === g ? '' : g)} aria-pressed={group === g} className={group === g ? '' : 'opacity-80 hover:opacity-100'}>
              <BloodTag group={g} size="sm" className={group === g ? 'ring-2 ring-ink ring-offset-2 ring-offset-paper' : ''} />
            </button>
          ))}
        </div>
        {reqs && list.length === 0 && (
          <div className="panel p-10 text-center"><p className="font-display text-xl font-extrabold">No active requests match.</p><p className="mt-1 text-mute">Clear the filters, or raise an SOS if someone needs blood.</p></div>
        )}
        <div className="grid gap-5 md:grid-cols-2">{list.map((r) => <SosCard key={r.id} r={r} />)}</div>
      </section>
    </div>
  );
}
