import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, UserPlus } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/ctx.jsx';
import { GROUPS } from '../lib/compat.js';
import BloodTag from '../components/BloodTag.jsx';

export default function Donors() {
  const { meta, donors, refreshDonors, setDonorId, notify } = useApp();
  const nav = useNavigate();
  const [f, setF] = useState({ name: '', phone: '', blood_group: 'O+', city: 'Hyderabad', locality: '', healthy: false });
  const [filter, setFilter] = useState({ group: '', city: '' });
  const [busy, setBusy] = useState(false);
  useEffect(() => { refreshDonors(); }, [refreshDonors]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const areas = meta?.geo[f.city] || [];

  async function submit(e) {
    e.preventDefault();
    if (!f.name.trim() || f.phone.replace(/\D/g, '').length < 10 || !f.locality || !f.healthy) return notify('Fill in every field and confirm the health declaration.', 'err');
    setBusy(true);
    try {
      const d = await api.registerDonor(f);
      await refreshDonors(); setDonorId(String(d.id));
      notify('You are on the donor registry. Your number stays private.');
      nav('/me');
    } catch (err) { notify(err.message, 'err'); } finally { setBusy(false); }
  }

  const shown = donors.filter((d) => (!filter.group || d.blood_group === filter.group) && (!filter.city || d.city === filter.city));

  return (
    <div className="grid gap-8 lg:grid-cols-[400px_1fr]">
      <form onSubmit={submit} className="panel space-y-4 p-6 lg:sticky lg:top-6 lg:self-start">
        <h1 className="text-2xl font-black">Become a voluntary donor</h1>
        <p className="text-sm text-mute">Your number is stored privately. Requests reach you through the app, and families can only message you after you say "I Can Donate".</p>
        <div><label className="lbl" htmlFor="dn">Name</label><input id="dn" className="field" value={f.name} onChange={set('name')} /></div>
        <div><label className="lbl" htmlFor="dp">Mobile (kept private)</label><input id="dp" inputMode="tel" className="field" value={f.phone} onChange={set('phone')} placeholder="10 digits" /></div>
        <div>
          <p className="lbl">Blood group</p>
          <div className="flex flex-wrap gap-1.5">{GROUPS.map((g) => <button type="button" key={g} onClick={() => setF({ ...f, blood_group: g })} aria-pressed={f.blood_group === g} className={`rounded p-0.5 ${f.blood_group === g ? 'ring-2 ring-blood ring-offset-2 ring-offset-label' : ''}`}><BloodTag group={g} size="md" /></button>)}</div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="lbl" htmlFor="c">City</label><select id="c" className="field" value={f.city} onChange={(e) => setF({ ...f, city: e.target.value, locality: '' })}>{meta && Object.keys(meta.geo).map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label className="lbl" htmlFor="l">Locality</label><select id="l" className="field" value={f.locality} onChange={set('locality')}><option value="">Choose</option>{areas.map((a) => <option key={a}>{a}</option>)}</select></div>
        </div>
        <label className="flex items-start gap-3 text-sm"><input type="checkbox" className="mt-1" checked={f.healthy} onChange={set('healthy')} />I am 18-65, weigh over 50 kg, healthy, and have not donated in the last 90 days.</label>
        <button className="btn btn-blood w-full" disabled={busy}><UserPlus size={18} />{busy ? 'Registering…' : 'Join the registry'}</button>
      </form>

      <section>
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div><h2 className="text-2xl font-black">Donor registry</h2><p className="text-sm text-mute">{shown.length} donors. Public view: initials and locality only.</p></div>
          <div className="flex gap-2">
            <select className="field !w-auto !py-1.5 text-sm" value={filter.group} onChange={(e) => setFilter({ ...filter, group: e.target.value })} aria-label="Blood group"><option value="">All groups</option>{GROUPS.map((g) => <option key={g}>{g}</option>)}</select>
            <select className="field !w-auto !py-1.5 text-sm" value={filter.city} onChange={(e) => setFilter({ ...filter, city: e.target.value })} aria-label="City"><option value="">All cities</option>{meta && Object.keys(meta.geo).map((c) => <option key={c}>{c}</option>)}</select>
          </div>
        </div>
        <ul className="grid gap-3 sm:grid-cols-2">
          {shown.map((d) => (
            <li key={d.id} className="panel flex items-center gap-3 p-3">
              <BloodTag group={d.blood_group} size="lg" />
              <div className="min-w-0 flex-1">
                <p className="font-display text-lg font-extrabold leading-tight">{d.initials}</p>
                <p className="truncate text-sm text-mute">{d.locality}, {d.city}</p>
              </div>
              <div className="text-right text-xs">
                <p className="flex items-center justify-end gap-1 font-mono text-mute"><Lock size={12} />•••• ••••••</p>
                {d.locked_until ? <p className="font-semibold text-amber">Recovering</p> : d.available ? <p className="font-semibold text-saline">Available</p> : <p className="font-semibold text-mute">Paused</p>}
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
