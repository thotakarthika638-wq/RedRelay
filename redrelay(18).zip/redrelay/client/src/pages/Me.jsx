import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, Lock, MessageSquare, Lock as LockIcon, MapPin, Clock } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/ctx.jsx';
import { ago, countdown, useInterval, useNow } from '../lib/time.js';
import { downloadCertificate } from '../lib/certificate.js';
import BloodTag from '../components/BloodTag.jsx';

export default function Me() {
  const { donorId, refreshDonors, notify, donors, setDonorId } = useApp();
  const now = useNow(30000);
  const [d, setD] = useState(null), [alerts, setAlerts] = useState([]), [inbox, setInbox] = useState([]);

  const load = useCallback(async () => {
    if (!donorId) return;
    try {
      const [dd, al, ib] = await Promise.all([api.donor(donorId), api.alerts(donorId), api.inbox(donorId)]);
      setD(dd); setAlerts(al); setInbox(ib);
    } catch (e) { notify(e.message, 'err'); }
  }, [donorId, notify]);
  useEffect(() => { load(); }, [load]);
  useInterval(load, 6000);

  if (!donorId) {
    return (
      <div className="panel mx-auto max-w-lg p-8 text-center">
        <h1 className="text-2xl font-black">Choose who you are</h1>
        <p className="mt-2 text-mute">Pick a registered donor to see their alerts, or register a new donor.</p>
        <select className="field mt-5" value="" onChange={(e) => setDonorId(e.target.value)} aria-label="Pick a donor">
          <option value="">Pick a donor</option>
          {donors.map((x) => <option key={x.id} value={x.id}>{x.initials} · {x.blood_group} · {x.locality}</option>)}
        </select>
        <Link to="/donors" className="btn btn-blood mt-4">Register as a donor</Link>
      </div>
    );
  }
  if (!d) return <p className="text-mute">Loading your page…</p>;

  const toggle = async () => {
    try { await api.setAvailability(d.id, !d.available); await load(); refreshDonors(); notify(d.available ? 'Paused. You will not get new alerts.' : 'You are available for alerts.'); }
    catch (e) { notify(e.message, 'err'); }
  };
  const respond = async (rid) => {
    try { await api.respond(rid, d.id); notify('Committed. The family can now message you through the app.'); load(); }
    catch (e) { notify(e.message, 'err'); }
  };
  const daysLeft = d.locked_until ? Math.ceil((d.locked_until - now) / 86400e3) : 0;
  const fmt = (t) => new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="grid gap-6 lg:grid-cols-[340px_1fr]">
      <aside className="space-y-4">
        <div className="panel overflow-hidden">
          <div className="flex items-center gap-4 border-b-2 border-dashed border-ink/25 p-5">
            <BloodTag group={d.blood_group} size="xl" />
            <div className="min-w-0">
              <p className="truncate font-display text-xl font-extrabold">{d.name}</p>
              <p className="flex items-center gap-1 text-sm text-mute"><MapPin size={14} />{d.locality}, {d.city}</p>
              <p className="mt-1 flex items-center gap-1 font-mono text-xs text-mute"><LockIcon size={12} />{d.phone_masked} · hidden from everyone</p>
            </div>
          </div>
          <div className="space-y-3 p-5">
            {d.locked_until ? (
              <div className="rounded-md bg-amber-soft p-3 text-sm">
                <p className="flex items-center gap-2 font-bold"><Lock size={16} />Recovery window: {daysLeft} days left</p>
                <p className="mt-1 text-ink/80">You donated on {fmt(d.last_donation_at)}. Availability stays locked for 90 days for your safety. Back on {fmt(d.locked_until)}.</p>
              </div>
            ) : (
              <button onClick={toggle} role="switch" aria-checked={d.available} className="flex w-full items-center justify-between rounded-md border border-rule bg-label p-3 text-left">
                <span><span className="block font-bold">{d.available ? 'Available for alerts' : 'Paused'}</span><span className="text-sm text-mute">{d.available ? 'Compatible SOS within 40 km reach you.' : 'Turn on to receive alerts.'}</span></span>
                <span className={`relative h-6 w-11 rounded-full transition ${d.available ? 'bg-saline' : 'bg-rule'}`}><span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${d.available ? 'left-[22px]' : 'left-0.5'}`} /></span>
              </button>
            )}
          </div>
        </div>

        <div className="panel p-5">
          <h2 className="flex items-center gap-2 text-lg font-extrabold"><MessageSquare size={18} />Relay inbox</h2>
          {inbox.length === 0 && <p className="mt-2 text-sm text-mute">Messages from families you committed to appear here. Your number is never shared.</p>}
          <ul className="mt-2 space-y-2">{inbox.map((m) => <li key={m.id} className="rounded-md bg-saline-soft p-3 text-sm"><p>{m.text}</p><p className="mt-1 text-xs text-mute">{m.hospital} · {ago(m.created_at, now)}</p></li>)}</ul>
        </div>
      </aside>

      <section className="space-y-8">
        <div>
          <h2 className="text-2xl font-black">SOS alerts for {d.blood_group}</h2>
          <p className="text-sm text-mute">Open requests you can safely give to, within 40 km.</p>
          {alerts.length === 0 && <p className="panel mt-3 p-6 text-mute">No compatible requests nearby right now. You will see them here the moment one is posted.</p>}
          <ul className="mt-3 space-y-3">
            {alerts.map((a) => (
              <li key={a.id} className="panel flex flex-wrap items-center gap-4 p-4">
                <BloodTag group={a.blood_group} size="lg" />
                <div className="min-w-0 flex-1">
                  <p className="font-display text-lg font-extrabold">{a.hospital}</p>
                  <p className="text-sm text-mute">{a.locality} · {a.distance_km} km · ~{a.eta_min} min drive · {a.units_committed}/{a.units_needed} committed</p>
                  <p className="flex items-center gap-1 font-mono text-sm font-bold text-blood"><Clock size={13} />{countdown(a.urgency_deadline, now)}</p>
                </div>
                {a.already_committed ? <Link to={`/sos/${a.id}`} className="btn btn-line btn-sm">You committed</Link>
                  : a.units_committed >= a.units_needed ? <Link to={`/sos/${a.id}`} className="btn btn-line btn-sm">Fully covered</Link>
                  : <><Link to={`/sos/${a.id}`} className="btn btn-line btn-sm">Details</Link><button onClick={() => respond(a.id)} disabled={!d.available} className="btn btn-blood btn-sm">I Can Donate</button></>}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="text-2xl font-black">Your donations</h2>
          {d.history.length === 0 && <p className="panel mt-3 p-6 text-mute">Nothing yet. Your first "I Can Donate" will show up here.</p>}
          <ul className="mt-3 space-y-3">
            {d.history.map((h) => (
              <li key={h.fulfillment_id} className="panel flex flex-wrap items-center gap-4 p-4">
                <BloodTag group={h.blood_group} size="md" />
                <div className="min-w-0 flex-1"><p className="font-bold">{h.hospital}, {h.locality}</p><p className="text-sm text-mute">{h.status === 'donated' ? `Donated ${fmt(h.donated_at)}` : `Committed ${ago(h.created_at, now)}`}</p></div>
                {h.status === 'donated'
                  ? <button className="btn btn-ink btn-sm" onClick={() => downloadCertificate({ name: d.name, group: d.blood_group, hospital: h.hospital, date: fmt(h.donated_at) })}><Download size={16} />Certificate</button>
                  : <Link to={`/sos/${h.request_id}`} className="btn btn-line btn-sm">Open request</Link>}
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
