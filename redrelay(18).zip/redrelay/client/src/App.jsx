import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import Feed from './pages/Feed.jsx';
import NewRequest from './pages/NewRequest.jsx';
import RequestDetail from './pages/RequestDetail.jsx';
import Donors from './pages/Donors.jsx';
import Me from './pages/Me.jsx';
import Matrix from './pages/Matrix.jsx';

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Feed />} />
        <Route path="/sos/new" element={<NewRequest />} />
        <Route path="/sos/:id" element={<RequestDetail />} />
        <Route path="/donors" element={<Donors />} />
        <Route path="/me" element={<Me />} />
        <Route path="/matrix" element={<Matrix />} />
        <Route path="*" element={<p className="p-10">Page not found.</p>} />
      </Routes>
    </Layout>
  );
}
