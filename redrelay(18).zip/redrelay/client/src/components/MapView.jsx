import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const COLORS = { A: '#F5D547', B: '#F29BB9', O: '#68A9EA', AB: '#FFFFFF' };
const abo = (g) => g.replace(/[+-]/, '');

// Hospital + responding/eligible donors with estimated driving time (OpenStreetMap tiles via Leaflet).
export default function MapView({ hospital, donors, radius }) {
  const el = useRef(null), map = useRef(null), layer = useRef(null);

  useEffect(() => {
    map.current = L.map(el.current, { scrollWheelZoom: false }).setView([hospital.lat, hospital.lng], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors', maxZoom: 18 }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => { map.current.remove(); map.current = null; };
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    const g = layer.current; if (!g) return;
    g.clearLayers();
    const hq = [hospital.lat, hospital.lng];
    L.circle(hq, { radius: radius * 1000, color: '#C8102E', weight: 1, dashArray: '6 6', fillColor: '#C8102E', fillOpacity: 0.05 }).addTo(g);
    const pin = L.divIcon({ className: '', iconSize: [34, 34], iconAnchor: [17, 17],
      html: '<div style="width:34px;height:34px;border-radius:8px;background:#C8102E;color:#fff;display:grid;place-items:center;font:900 22px Archivo,sans-serif;border:3px solid #fff;box-shadow:0 0 0 3px #C8102E55">+</div>' });
    const hm = L.marker(hq, { icon: pin, zIndexOffset: 1000 }).addTo(g);
    const ht = document.createElement('span'); ht.textContent = hospital.name; hm.bindTooltip(ht);
    const pts = [hq];
    donors.forEach((d) => {
      const p = [d.lat, d.lng]; pts.push(p);
      L.polyline([p, hq], { color: d.committed ? '#C8102E' : '#0E1B2C', weight: d.committed ? 3 : 1.5, opacity: d.committed ? 0.9 : 0.35, dashArray: d.committed ? null : '4 6' }).addTo(g);
      const icon = L.divIcon({ className: '', iconSize: [30, 22], iconAnchor: [15, 11],
        html: `<div style="width:30px;height:22px;border-radius:4px;background:${COLORS[abo(d.blood_group)]};border:1.5px solid #0E1B2C;display:grid;place-items:center;font:800 11px Archivo,sans-serif;color:#0E1B2C">${d.blood_group}</div>` });
      const m = L.marker(p, { icon }).addTo(g);
      const t = document.createElement('span'); t.textContent = `${d.initials} · ${d.locality} · ${d.distance_km} km · ~${d.eta_min} min drive${d.committed ? ' · committed' : ''}`; m.bindTooltip(t);
    });
    if (pts.length > 1) map.current.fitBounds(L.latLngBounds(pts), { padding: [30, 30], maxZoom: 14 });
    else map.current.setView(hq, 12);
  }, [hospital.lat, hospital.lng, hospital.name, donors, radius]);

  return <div ref={el} className="map-dim h-80 w-full rounded-lg border border-rule" />;
}
