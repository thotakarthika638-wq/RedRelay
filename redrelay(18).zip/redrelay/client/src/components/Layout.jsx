import { useCallback, useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Droplet, Siren, ShieldCheck } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/ctx.jsx';
import { useInterval } from '../lib/time.js';

function Ticker() {
  const [s, setS] = useState(null);
  const load = useCallback(() => api.stats().then(setS).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);
  useInterval(load, 8000);
  return (
    <div className="bg-ink text-white">
      <div className="mx-auto flex max-w-6xl items-center gap-5 overflow-x-auto whitespace-nowrap px-4 py-1.5 text-xs">
        <span className="flex items-center gap-1.5 font-bold text-white"><span className="h-2 w-2 rounded-full bg-blood animate-pulse" />LIVE</span>
        {s ? (
          <>
            <span><b className="font-mono">{s.active_requests}</b> active SOS</span>
            <span><b className="font-mono">{s.units_open}</b> units still needed</span>
            <span><b className="font-mono">{s.donors_available}</b> of {s.donors} donors on standby</span>
            <span><b className="font-mono">{s.units_donated}</b> units donated through RedRelay</span>
          </>
        ) : <span>Connecting to the relay…</span>}
      </div>
    </div>
  );
}

function Ecg() {
  return (
    <svg className="block h-5 w-full" viewBox="0 0 400 24" preserveAspectRatio="none" aria-hidden="true">
      <path d="M0 12H400" stroke="#C4D0D6" strokeWidth="1" fill="none" vectorEffect="non-scaling-stroke" />
      <path className="ecg-path" d="M0 12H110L120 12L128 3L138 21L146 12H190L198 8L206 12H400" stroke="#C8102E" strokeWidth="2" fill="none" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export default function Layout({ children }) {
  const { donors, donorId, setDonorId, toast } = useApp();
  const loc = useLocation();
  useEffect(() => window.scrollTo(0, 0), [loc.pathname]);
  const nav = ({ isActive }) => `rounded px-3 py-1.5 text-sm font-semibold ${isActive ? 'bg-ink text-white' : 'text-ink hover:bg-ink/10'}`;

  return (
    <div className="min-h-screen">
      <Ticker />
      <header className="border-b border-rule bg-paper/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
          <Link to="/" className="mr-2 flex items-center gap-2" aria-label="RedRelay home">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-blood text-white"><Droplet size={20} fill="currentColor" /></span>
            <span className="font-display text-2xl font-black leading-none tracking-tight" style={{ fontStretch: '115%' }}>RedRelay</span>
          </Link>
          <nav className="flex flex-wrap items-center gap-1">
            <NavLink to="/" end className={nav}>Live feed</NavLink>
            <NavLink to="/donors" className={nav}>Donors</NavLink>
            <NavLink to="/me" className={nav}>My donor page</NavLink>
            <NavLink to="/matrix" className={nav}>Compatibility</NavLink>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <label className="hidden items-center gap-2 text-xs text-mute md:flex">
              Demo identity
              <select value={donorId} onChange={(e) => setDonorId(e.target.value)} className="field !w-auto !py-1.5 text-sm" aria-label="Demo identity">
                <option value="">Guest (family)</option>
                {donors.map((d) => <option key={d.id} value={d.id}>{d.initials} · {d.blood_group} · {d.locality}{d.available ? '' : ' (unavailable)'}</option>)}
              </select>
            </label>
            <Link to="/sos/new" className="btn btn-blood btn-sm"><Siren size={16} />Raise an SOS</Link>
          </div>
        </div>
        <Ecg />
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>

      <footer className="mt-10 border-t border-rule bg-label">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-6 text-sm text-mute">
          <ShieldCheck size={18} className="text-saline" />
          <span>Donor phone numbers are never shown. Families and donors talk through in-app relay only.</span>
          <span className="ml-auto font-mono text-xs">RedRelay · LifeLine Hackathon build</span>
        </div>
      </footer>

      {toast && (
        <div key={toast.k} role="status" className={`fixed bottom-5 left-1/2 z-50 -translate-x-1/2 animate-rise rounded-md px-4 py-3 text-sm font-semibold text-white shadow-lg ${toast.kind === 'err' ? 'bg-blood-dark' : 'bg-ink'}`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
