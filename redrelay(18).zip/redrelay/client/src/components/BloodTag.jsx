import { abo } from '../lib/compat.js';

export const ISBT = { A: '#F5D547', B: '#F29BB9', O: '#68A9EA', AB: '#FFFFFF' };

// Blood group drawn like a blood-bag label: ISBT-128 colour by ABO group.
export default function BloodTag({ group, size = 'md', dim = false, className = '' }) {
  const a = abo(group), neg = group.endsWith('-');
  const sizes = { xs: 'text-xs px-1.5 py-0.5', sm: 'text-sm px-2 py-0.5', md: 'text-lg px-2.5 py-0.5', lg: 'text-3xl px-3 py-1', xl: 'text-6xl px-4 py-2' };
  return (
    <span
      title={`${group} (${neg ? 'Rh negative' : 'Rh positive'})`}
      className={`inline-flex items-baseline rounded border border-ink/70 font-display font-black leading-none ${sizes[size]} ${dim ? 'opacity-40' : ''} ${className}`}
      style={{ background: ISBT[a], fontStretch: '110%' }}
    >
      {a}
      <span className={`ml-0.5 font-black ${neg ? 'text-blood-dark' : 'text-ink'}`} style={{ fontSize: '.7em' }}>{neg ? '−' : '+'}</span>
    </span>
  );
}
