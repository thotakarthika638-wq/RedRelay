import { Check } from 'lucide-react';

export const STEPS = ['Open / Broadcasted', 'Donors Responded', 'Fulfilled / In Transit', 'Closed'];
const IDX = { open: 0, responded: 1, in_transit: 2, closed: 3 };
const REASON = { received: 'Blood received', expired: 'Expired after 24 h', cancelled: 'Cancelled by family' };

export default function Stepper({ status, reason, compact = false }) {
  const cur = IDX[status] ?? 0;
  if (compact) {
    return (
      <div className="flex items-center gap-1" aria-label={`Status: ${STEPS[cur]}`}>
        {STEPS.map((s, i) => (
          <span key={s} className={`h-1.5 flex-1 rounded-full ${i <= cur ? (status === 'closed' ? 'bg-ink' : 'bg-blood') : 'bg-rule'}`} />
        ))}
      </div>
    );
  }
  return (
    <ol className="grid grid-cols-4 gap-1" aria-label="Request lifecycle">
      {STEPS.map((s, i) => {
        const done = i < cur || (status === 'closed' && i === 3), active = i === cur && status !== 'closed';
        return (
          <li key={s} className="relative flex flex-col items-start">
            <div className="flex w-full items-center">
              <span className={`relative z-10 grid h-8 w-8 shrink-0 place-items-center rounded-full border-2 text-sm font-bold ${done ? 'border-ink bg-ink text-white' : active ? 'border-blood bg-blood text-white' : 'border-rule bg-label text-mute'}`}>
                {active && <span className="absolute inset-0 rounded-full bg-blood animate-ping2" />}
                <span className="relative">{done ? <Check size={16} strokeWidth={3} /> : i + 1}</span>
              </span>
              {i < 3 && <span className={`h-0.5 flex-1 ${i < cur ? 'bg-ink' : 'bg-rule'}`} />}
            </div>
            <span className={`mt-2 pr-1 text-xs font-semibold leading-tight sm:text-sm ${active ? 'text-blood' : done ? 'text-ink' : 'text-mute'}`}>{s}</span>
            {i === 3 && status === 'closed' && reason && <span className="text-xs text-mute">{REASON[reason]}</span>}
          </li>
        );
      })}
    </ol>
  );
}
