import { useId } from 'react';

// Blood bag that fills as donors commit units. Solid = donated/received, lighter = committed.
export default function Bag({ committed = 0, needed = 1, received = 0, size = 56 }) {
  const id = useId();
  const pct = Math.min(1, committed / needed), rpct = Math.min(1, received / needed);
  const top = 12, bottom = 74, h = bottom - top;
  return (
    <svg width={size} height={size * 1.33} viewBox="0 0 60 80" role="img" aria-label={`${committed} of ${needed} units committed`}>
      <defs>
        <clipPath id={id}>
          <path d="M18 6h24v6q10 4 10 16v34q0 12-12 12H20q-12 0-12-12V28q0-12 10-16z" />
        </clipPath>
      </defs>
      <g clipPath={`url(#${id})`}>
        <rect x="0" y="0" width="60" height="80" fill="#FBE3E7" />
        <rect x="0" y={bottom - h * pct} width="60" height={h * pct + 8} fill="#E7536B" style={{ transition: 'all .6s ease' }} />
        <rect x="0" y={bottom - h * rpct} width="60" height={h * rpct + 8} fill="#C8102E" style={{ transition: 'all .6s ease' }} />
        {[0.25, 0.5, 0.75].map((t) => <line key={t} x1="38" x2="50" y1={bottom - h * t} y2={bottom - h * t} stroke="#0E1B2C" strokeOpacity=".35" />)}
      </g>
      <path d="M18 6h24v6q10 4 10 16v34q0 12-12 12H20q-12 0-12-12V28q0-12 10-16z" fill="none" stroke="#0E1B2C" strokeWidth="2.5" strokeLinejoin="round" />
      <rect x="25" y="1" width="10" height="6" rx="1.5" fill="#0E1B2C" />
    </svg>
  );
}
