import { Link } from 'react-router-dom';
import { Clock, MapPin, BadgeCheck } from 'lucide-react';
import BloodTag, { ISBT } from './BloodTag.jsx';
import Bag from './Bag.jsx';
import Stepper from './Stepper.jsx';
import { abo } from '../lib/compat.js';
import { countdown, isCritical, useNow } from '../lib/time.js';

export default function SosCard({ r }) {
  const now = useNow();
  const crit = isCritical(r, now), closed = r.status === 'closed';
  const left = r.units_needed - r.units_committed;
  return (
    <Link
      to={`/sos/${r.id}`}
      className={`group relative flex overflow-hidden rounded-lg border bg-label transition hover:-translate-y-0.5 hover:border-ink ${crit ? 'border-blood animate-sos' : 'border-rule'} ${closed ? 'opacity-70' : ''}`}
    >
      <div className="flex w-28 shrink-0 flex-col items-center justify-center gap-1 border-r-2 border-dashed border-ink/30 px-2 py-4 sm:w-32" style={{ background: ISBT[abo(r.blood_group)] }}>
        <span className="font-display text-5xl font-black leading-none sm:text-6xl" style={{ fontStretch: '110%' }}>
          {abo(r.blood_group)}<span className={`text-3xl ${r.blood_group.endsWith('-') ? 'text-blood-dark' : ''}`}>{r.blood_group.endsWith('-') ? '−' : '+'}</span>
        </span>
        <span className="text-xs font-semibold text-ink/80">{r.units_needed} unit{r.units_needed > 1 ? 's' : ''} needed</span>
      </div>
      <span className="absolute -top-2 left-[6.6rem] h-4 w-4 rounded-full bg-paper sm:left-[7.6rem]" />
      <span className="absolute -bottom-2 left-[6.6rem] h-4 w-4 rounded-full bg-paper sm:left-[7.6rem]" />

      <div className="flex min-w-0 flex-1 flex-col gap-3 p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="truncate text-lg font-extrabold leading-tight">{r.hospital}</h3>
            <p className="flex items-center gap-1 text-sm text-mute"><MapPin size={14} />{r.locality}, {r.city} · patient {r.patient}</p>
          </div>
          {crit && !closed && (
            <span className="flex shrink-0 items-center gap-1.5 rounded bg-blood px-2 py-1 text-xs font-bold text-white">
              <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full rounded-full bg-white animate-ping2" /><span className="relative h-2 w-2 rounded-full bg-white" /></span>
              Critical
            </span>
          )}
        </div>

        <div className="flex items-center gap-4">
          <Bag committed={r.units_committed} needed={r.units_needed} received={r.units_received} size={34} />
          <div>
            <p className="font-display text-2xl font-extrabold leading-none"><span className="tabular-nums">{r.units_committed}/{r.units_needed}</span> <span className="text-base font-bold">units committed</span></p>
            <p className="mt-1 text-sm text-mute">{closed ? 'Closed' : left > 0 ? `${left} more needed` : 'All units committed'}</p>
          </div>
        </div>

        <Stepper status={r.status} reason={r.closed_reason} compact />

        <div className="flex items-center justify-between text-sm">
          <span className={`flex items-center gap-1 font-mono font-bold ${crit && !closed ? 'text-blood' : 'text-ink'}`}><Clock size={14} />{closed ? '—' : countdown(r.urgency_deadline, now)}</span>
          <span className="flex items-center gap-1 text-saline"><BadgeCheck size={15} />Doctor verified</span>
        </div>
      </div>
    </Link>
  );
}
