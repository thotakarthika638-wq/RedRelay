/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#E6EDF0',
        label: '#F8FBFB',
        ink: '#0E1B2C',
        mute: '#5B6B7C',
        rule: '#C4D0D6',
        blood: { DEFAULT: '#C8102E', dark: '#8E0B20', soft: '#FBE3E7' },
        saline: { DEFAULT: '#0E7C86', soft: '#D6EEF0' },
        amber: { DEFAULT: '#D98E04', soft: '#FCEFCF' },
        // ISBT-128 blood-bag label colours (what blood banks actually use)
        isbt: { a: '#F5D547', b: '#F29BB9', o: '#68A9EA', ab: '#FFFFFF' },
      },
      fontFamily: {
        display: ['Archivo', 'Arial Narrow', 'Arial', 'sans-serif'],
        sans: ['"Public Sans"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      keyframes: {
        sos: { '0%': { boxShadow: '0 0 0 0 rgba(200,16,46,.55)' }, '70%': { boxShadow: '0 0 0 14px rgba(200,16,46,0)' }, '100%': { boxShadow: '0 0 0 0 rgba(200,16,46,0)' } },
        ping2: { '0%': { transform: 'scale(1)', opacity: '.7' }, '100%': { transform: 'scale(2.6)', opacity: '0' } },
        ecg: { to: { strokeDashoffset: '-400' } },
        rise: { from: { transform: 'translateY(6px)', opacity: '0' }, to: { transform: 'none', opacity: '1' } },
      },
      animation: { sos: 'sos 1.6s ease-out infinite', ping2: 'ping2 1.4s ease-out infinite', ecg: 'ecg 2.4s linear infinite', rise: 'rise .25s ease-out' },
    },
  },
  plugins: [],
};
