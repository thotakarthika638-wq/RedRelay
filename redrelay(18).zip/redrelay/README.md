# RedRelay: LifeLine Hackathon solution

Emergency blood SOS and private donor coordination. Verified requests are matched to compatible nearby donors using the clinical ABO/Rh matrix. Donor phone numbers are never exposed.

**Stack:** React 18 + React Router + Tailwind CSS (Vite) · Node.js + Express · SQLite · Leaflet/OpenStreetMap

## Run it

Requires Node.js 18 or newer.

```bash
npm run install:all     # installs root, server and client dependencies
npm run dev             # API on :4000, web app on http://localhost:5173
```

The database file is created and seeded automatically on first start (30 donors, 5 active requests). Reset it any time with `npm run seed`.

Production-style single server: `npm start` builds the client and serves everything from http://localhost:4000.

> If `better-sqlite3` fails to install on your machine, the server falls back to Node's built-in `node:sqlite` (Node 22.5+). Nothing else to change.

## Feature checklist

| Brief requirement | Where |
|---|---|
| SOS form (patient, hospital, group, units, deadline, doctor contact) with urgency validation | `client/src/pages/NewRequest.jsx`, `POST /api/requests` |
| ABO/Rh compatibility engine | `server/compat.js` (mirrored in `client/src/lib/compat.js`), page `/matrix` |
| Four-stage lifecycle stepper | `components/Stepper.jsx`; Open / Broadcasted → Donors Responded → Fulfilled / In Transit → Closed |
| Donor registry with privacy masking | `pages/Donors.jsx`; public API returns initials and locality only |
| City and radius filter | Request page: city select and 2-50 km slider, haversine on the server |
| Broadcast feed with red urgency pulse and units counters | `pages/Feed.jsx`, `components/SosCard.jsx` (polls every 5 s) |
| SMS dispatch simulator (stretch) | "SMS SOS dispatch" panel on a request, `POST /api/requests/:id/broadcast` |
| Routing map with drive-time estimates (stretch) | `components/MapView.jsx` (Leaflet + OpenStreetMap) |
| 90-day donation lock (stretch) | Set when a donation is confirmed; blocks availability and responding |
| Donor appreciation certificate (stretch) | "Certificate" button on `/me`, drawn on canvas and downloaded as PNG |

Anti-ghost-request: every request expires 24 hours after creation, deadlines are capped at 24 h, and families get **Mark blood received** and **Cancel** actions.

## Privacy design

- Donor phone numbers are stored server-side only. No endpoint returns them (only the last two digits on the donor's own page).
- Public views show initials and locality. Map pins are rounded to about 1 km.
- Families can message only donors who committed, through the in-app relay. Donors read messages in their inbox.
- The doctor's number is masked and the patient's name is shortened on the public feed.
- A request is managed with a short **family access code** shown once after creation (also saved in the browser).

## Demo script (matches the brief)

1. Open the feed. Four SOS cards are live; the Apollo B+ card shows `0/2 units`.
2. Click **Raise an SOS**, choose B+, 2 units, Apollo Hospital, Jubilee Hills, within 4 hours. The sidebar shows eligible donors: B+, B−, O+, O−. Broadcast it (or use the seeded Apollo request).
3. On the request page, see the compatible pool, change radius/city, open the map, and press **Dispatch SOS alerts** to see the simulated SMS log (numbers masked).
4. Switch **Demo identity** (top right) to an O+ donor, for example `S.I. · O+ · Gachibowli`. Click **I Can Donate**. The card becomes `1/2 units committed` and the stepper moves to **Donors Responded**.
5. Switch to a B+ donor and commit again: `2/2`, stepper moves to **Fulfilled / In Transit**.
6. As the family, unlock with access code `demo-1` (seeded requests use `demo-1` to `demo-5`). Send a relay message, confirm donations, then **Mark blood received** to close the request.
7. Open **My donor page** as the O+ donor: the 90-day recovery lock is active and the certificate can be downloaded.

## API

```
GET  /api/meta                       blood groups, matrix, cities and localities
GET  /api/stats                      live counters
GET  /api/requests[?closed=1]        public feed
POST /api/requests                   create SOS, returns access code
GET  /api/requests/:id               detail with masked responders
GET  /api/requests/:id/matches       ?radius=25&city=Hyderabad
POST /api/requests/:id/respond       { donor_id }   "I Can Donate"
POST /api/requests/:id/status        { token, action: in_transit | received | cancel }
POST /api/requests/:id/broadcast     simulated SMS dispatch
POST /api/requests/:id/relay         { token, donor_id, message }
POST /api/fulfillments/:id/confirm   { token } or { donor_id }  starts 90-day lock
GET  /api/donors, POST /api/donors, GET /api/donors/:id
PATCH /api/donors/:id/availability   GET /api/donors/:id/alerts, /inbox
```

Tables: `donors`, `requests`, `fulfillments`, `relay_messages`, `sms_log`.

## Notes and trade-offs

- Donor identity is a "demo identity" switcher instead of passwords, so a presenter can flip between roles in seconds. Swap in real OTP login for production.
- Each donor commits one unit per request (the clinical standard of one unit per donation).
- Drive times are estimates from straight-line distance, not live routing.

## Security hardening (demo deployment)

- API request throttling: 120 requests/minute/IP overall and 30 write requests/minute/IP; returns HTTP 429 with `Retry-After`.
- Restricted CORS: localhost development origins by default. Set `CORS_ORIGINS` to a comma-separated allowlist of your deployed frontend origins.
- Security response headers, disabled Express fingerprint header, bounded JSON request bodies, malformed numeric-ID rejection, and sanitized server error responses.
- Family access codes now use 12 hex characters (6 random bytes) for newly created requests.
- SQLite indexes cover feed/deadline, donor filtering, donation history, relay inbox and SMS log lookups.
- Compatibility rules have Node test coverage (`npm test --prefix server`).

**Important:** RedRelay still uses a demo-identity switcher and is not production-ready for real patient or donor data. These safeguards improve the demo, but real deployment requires verified identity/authentication and authorization for donor/family actions, secure token storage, audited access, encrypted backups, consent/privacy review, HTTPS, a persistent shared rate-limit store, and healthcare professional oversight. Never use the seeded demo identities for real donations.

Set deployment origins, for example:

```bash
CORS_ORIGINS=https://your-frontend.example TRUST_PROXY=1 npm start --prefix server
```

## Advanced architecture & explainable matching (v2 enhancement)

### Modular matching service
The donor ranking and request-priority calculations are isolated in `server/matching.js` as pure functions. This separates business rules from Express routes, makes the logic easier to test, and supports future replacement with a more advanced matching service without changing API consumers.


### Smart donor ranking (0–100)
Compatible donors are ranked using an explainable score:
- **Proximity (0–35):** closer donors receive a higher score.
- **Exact blood group (0 or 25):** exact group receives the bonus; compatibility is still checked first.
- **Urgency (0–20):** requests with nearer deadlines score higher.
- **Availability (0 or 10):** currently available donors receive the bonus.
- **Uncommitted status (0 or 10):** donors who have not already committed are prioritized.

The matching response now includes `score`, `tier`, and `reasons` (e.g. exact match, nearby donor, urgent request) and sorts donors by score. The UI displays this information to make the ranking transparent. **This score is a coordination aid—not a clinical eligibility decision.** Donation eligibility and final screening must be decided by qualified blood-bank staff.


### Request priority endpoint
`GET /api/requests/:id/priority` returns an explainable **0–100 priority score**, its tier (`Critical`, `High`, `Medium`, `Low`), remaining units, deadline in hours, and a score breakdown. Priority is based on deadline pressure (0–60) and remaining units (0–40). This enables future dashboard sorting and dispatcher workflows.


### Architecture flow

```text
React UI
  └─ API client
      └─ Express routes (validation / rate limiting)
          ├─ Matching service (compatibility + scoring + reasons)
          ├─ Request priority service (deadline + shortage)
          ├─ Geospatial utilities (distance + ETA estimate)
            └─ SQLite data layer (indexed requests, donors, fulfillments)
```

### New tests
`server/test/matching.test.js` covers score/tier output, incompatible donor rejection, committed-donor ranking, and urgency/shortage priority. Run the full server suite with:


```bash
npm test --prefix server
```
